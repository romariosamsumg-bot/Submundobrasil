# Próximos passos

## Implementado na 0.5

- [x] Correção de XSS via save; validação e higienização campo a campo
- [x] Backup de save ilegível e do save da 0.4; aviso e download
- [x] Migração completa 0.4 → 0.5 (testada com save real gerado pela 0.4)
- [x] Exportação com checksum; importação também pela tela inicial
- [x] Sincronização entre abas; tela de erro com exportação em caso de falha de renderização
- [x] Bloqueio de compras, melhorias e fundação de gangue durante a detenção; fiança
- [x] Missões por atributo (13, sendo 5 exclusivas de bairro), requisitos, consequências específicas, fadiga de repetição e respeito decrescente
- [x] Vigilância local e economia por bairro, dinâmicas
- [x] Especializações com XP e 3 habilidades cada
- [x] Banco com taxa; negócios por bairro, revenda, extorsão; tributo; sociedades
- [x] Equipe com nomes, funções, níveis e deserção
- [x] IA de facções com personalidade, força, rancor, guerra entre facções, propostas, traição
- [x] Alianças com benefícios e compromissos; trégua como compromisso; custo de romper acordos
- [x] 15 eventos (Carnaval e Clássico fixos) com efeitos concretos; 10 tipos de notícia
- [x] Pontuação em 5 categorias com medalhas, títulos, ranking de poder simulado, 18 conquistas, recordes, prestígio, rival histórico
- [x] Confirmação de dois toques em "Avançar dia", cartão de resultado com variações e resumo do dia
- [x] Simulação de balanceamento e testes automatizados
- [x] Direção de arte "rua brasileira": HUD fixo com retrato, cenas SVG por bairro que reagem a eventos, placa de rua, lambe-lambe, cupom com carimbo, fita zebrada, dossiês de facção, cartinhas de integrantes, capa e transição de amanhecer

- [x] **v0.6**: seis cidades reais com bairros, grupos, negócios, festas e vantagem próprios; introdução "Como jogar", trilha de primeiros passos e cartão "Seu rumo"; Operador com +8% em serviços grandes

- [x] **v0.7**: Feira do Rolo (armas, proteção, veículos), Galpão (mercadorias, produção, comprador de fora, blitz), vida noturna, Perfil, aba Cidade e categoria Comércio

- [x] **v0.8**: saúde (barra no topo), ferimentos, internação, Hospital (posto e clínica) e Duelos de rua contra 8 adversários

- [x] **v0.9**: linha adulta 18+ (aviso obrigatório), arsenal de 16 armas e 6 proteções, 5 serviços novos, noite com Pagode, Baile e Termas VIP, UPA, advogado de porta de cadeia e suborno do carcereiro

O que falta para lançar está em **LANCAMENTO.md**.

## Pendências de balanceamento (prioridade alta)

1. **Articulador forte na estratégia de gangue** (191 contra 172 do Operador): rever o bônus de +5 em confrontos.
2. **Articulador levemente forte como generalista**: reduzir o bônus de influência das notícias para +15% (hoje +30% em tudo).
3. **Empreendedor fraco fora dos negócios** (151–171): considerar +1 de XP por compra de treino ou uma habilidade híbrida.
4. **Estratégia de gangue com caixa baixo**: avaliar com pessoas se é frustrante; uma opção é a operação coletiva render mais com integrantes de nível alto.
5. Repetir a calibração das medalhas após cada mudança (`npm run simulate`).

## Conteúdo e profundidade (prioridade média)

- Reforma de negócios (nível 2, +60% de renda, mais visado por extorsão).
- Missões em cadeia (3 etapas com escolhas) por bairro.
- Eventos de carreira (por exemplo, "Oferta de sociedade grande" exclusiva para o Empreendedor nível 2).
- Relações entre facções dinâmicas (hoje as inimizades são fixas): permitir que duas facções se aliem contra você se você liderar 3 bairros.
- Integrantes com traço pessoal (leal, ambicioso, nervoso) e possibilidade de promoção a "braço direito".
- Mais cidades com bairros próprios (a cidade de origem hoje é só texto).

## Interface (prioridade média)

- Testar em Safari/iOS e Firefox Android.
- Fonte de títulos: sem arquivo de fonte embutido, o visual condensado depende do aparelho (Impact/Roboto Condensed); avaliar embutir uma fonte livre em base64 (~20 KB).
- Cenas: variação dia/noite conforme o dia da temporada e pequenos personagens; retratos para integrantes e líderes de facção.
- Sons curtos opcionais (carimbo, moedas) com botão de mudo.
- Telas Banco e Temporada ainda são as mais "cartão"; dar a elas metáforas próprias (caderneta, quadro de troféus).
- Gráfico simples da evolução da influência por bairro na tela Bairros.
- Leitor de tela: revisar a ordem de foco e os anúncios do cartão de resultado.

## Arquitetura (prioridade baixa até haver backend)

- Versionar a migração com uma função por versão (`migrate1to2`, `migrate2to3`) quando surgir o schema 3.
- Mover as tabelas de dados para um bloco JSON separado para facilitar o balanceamento.
- Ver "Backend e multiplayer" em PROJECT_CONTEXT.md antes de qualquer recurso online.

## Depois da v0.7 (ideias do gênero ainda não feitas)

- **Arte dos lugares**: os lugares da aba Cidade usam ícones; merecem ilustrações próprias como as cenas dos bairros.
- **Operações grandes de gangue** em etapas (planejar, reunir, executar), com requisito de poder da equipe.
- **Negócios da noite**: comprar o boteco ou a casa noturna que você frequenta.
- **Jogo do bicho, caça-níquel e agiotagem** como negócios de contravenção brasileiros.
- **Estoque separado**: o que está no galpão não viaja com você (hoje toda a carga anda junto).
- **Tarefas encadeadas** de um padrinho, com recompensas, como continuação dos primeiros passos.
- Recalibrar as cidades com as mecânicas novas (a tabela de cidades é da v0.6).

## Pendências da v0.8

- O Empreendedor continua fraco fora dos negócios e na gangue (142–175).
- Adversários de duelo não reagem (não lembram derrotas, não cobram revanche); dá para ligar ao rancor das facções.
- Carga do Galpão pode ficar acima da capacidade se o jogador vender um veículo maior? Hoje a troca é bloqueada nesse caso; vender sem trocar ainda não existe.

## Próximo: assaltos de gangue em etapas (proposta do autor, v0.9)

Escada de assaltos que exige tamanho de bando, poder médio de arma e proteção:
Arrastão em shopping (3) → Caminhão de carga (5) → Agência no interior (6) → Carro-forte na serra (8) → Transportadora de valores (10) → Cofre central (12).
Cada um: planejar (custo e dias), reunir (energia de todos), executar (chance por poder do bando), dividir (manutenção e ânimo). Itens pesados (Ponto Cinquenta, MAG, Lança-rojão) ganham uso real aqui.
Também sugerido: rebelião na cadeia com a gangue.
