# Submundo Brasil — Game Design (v1.3)

Documento de referência das mecânicas. Os números aqui são os do código em
`src/engine.js`. Se você mudar um valor no código, atualize este documento.

---

## 1. Auditoria da versão 0.4

Legenda: **[C]** comprovado (reproduzido por teste ou bot), **[I]** comprovado
por leitura do código, **[H]** hipótese ainda não medida.

### 1.1 Críticos (perda de dados e segurança)

| # | Problema | Evidência | Correção na 0.5 |
|---|---|---|---|
| C1 | **XSS por save importado ou editado**: `h.season` (histórico) e `item.day` (registro) eram inseridos no HTML sem escape. | [C] Um `<img onerror>` executou nos dois campos (Playwright, `audit04.js`). | Toda saída passa por `esc()`/`num()`, e `normalizeSave` reconstrói cada campo com o tipo correto e descarta chaves desconhecidas. Teste: `ui.test.js` §4. |
| C2 | **Perda silenciosa do save**: qualquer falha de validação (JSON truncado, um valor fracionado) levava à tela inicial, e o novo jogo sobrescrevia o save antigo. | [C] Um save com `cash: 100.5` foi descartado. | O conteúdo ilegível é copiado para `submundo_brasil_corrupt_backup`, a tela inicial avisa o motivo e oferece download. Números fora de faixa são **limitados** em vez de rejeitados. |
| C3 | Sem backup antes de migração. | [I] | O save original da 0.4 é guardado em `submundo_brasil_v04_backup`, com botão para baixar. |
| C4 | Duas abas abertas sobrescreviam o progresso uma da outra. | [I] | Escuta o evento `storage` e recarrega o estado da outra aba. [H] Edição simultânea nas duas abas ainda prevalece a última gravação. |

### 1.2 Bugs e inconsistências

| # | Problema | Evidência |
|---|---|---|
| B1 | Era possível comprar negócios, melhorar a sede e fundar gangue **detido**. | [C] Compra do bar com `jail: 2`. |
| B2 | Tensão das facções nunca diminuía naturalmente; a relação nunca voltava ao padrão. | [I] |
| B3 | O "rival" de cada bairro só crescia (+2 a 5 por dia, aleatório) e não havia disputa entre facções. | [I] |
| B4 | Meta **Patrimônio** contava negócios pelo preço de compra: comprar era "gratuito" para a meta. | [I] |
| B5 | "Avançar dia" sem confirmação: um toque acidental desperdiçava 100 de energia. | [I] |
| B6 | Energia e vigilância apareciam duplicadas no painel. | [I] |
| B7 | `confirm()` nativo era a única confirmação; não havia resumo do dia. | [I] |

### 1.3 Economia e exploração

| # | Problema | Evidência |
|---|---|---|
| E1 | **Banco sem custo** anulava o risco: depositar tudo após cada ação tornava as falhas inofensivas (perda de 12% do caixa **em mãos**). | [C] Bot "missões + banco": até R$ 29.251 em uma temporada, com caixa sempre 0. |
| E2 | **Astúcia dominava**: peso 1,7 na fórmula única de missões; Força, Lábia e Influência quase não importavam para ganhar dinheiro. | [I] |
| E3 | Operação coletiva sem limite diário e sem efeito no território: repetível até acabar a energia. | [I] |
| E4 | "Criar contatos" sem limite: R$ 180 por +12 de influência, e +2 de respeito por uso, permitia comprar o controle de um bairro em 2 dias. | [I] |
| E5 | Negócios com retorno em cerca de 15 dias e nenhum risco: comprar todos cedo era sempre a melhor escolha. | [I] |
| E6 | Repetir a missão mais lucrativa não tinha penalidade além da vigilância global. | [I] |
| E7 | Alta variância: o mesmo bot terminou entre R$ 7.392 e R$ 24.431. | [C] 2 temporadas por estratégia, número pequeno. |

### 1.4 Profundidade e integração

- **Facções** só diferiam por um número (`temperament`). Não tinham objetivo, força, memória nem decisões próprias.
- **Bairros** eram estáticos (bônus e risco fixos); liderar dava só +12% nas missões.
- **Eventos** eram 6 textos com ±% de um dia, sem relação com a ambientação brasileira.
- **Carreiras** eram passivas fixas, sem progressão dentro da temporada.
- **Temporada**: o "ranking" era só o histórico; a vitória era medida por dinheiro e respeito.
- Missões, facções, negócios e bairros **não se afetavam** entre si.

### 1.5 O que estava bom e foi preservado

Interface por cliques, as 6 telas e a navegação inferior no celular, a estética
(serifas, tons terrosos, sem neon), o ciclo de 30 dias, a meta de temporada, as
notícias com escolhas, tréguas, ânimo e manutenção da equipe, a exportação em
JSON e o caráter fictício e abstrato das ações.

---

## 2. Princípios de design da 0.5

1. **Toda vantagem tem custo**: proteger dinheiro custa taxa, liderar bairros atrai vigilância e facções, alianças têm contribuição diária, e romper acordos derruba a confiança de todos.
2. **Diversidade obrigatória por regra, não por limite artificial**: repetir a mesma missão e insistir no mesmo bairro piora chance e recompensa (fadiga e vigilância local). O jogador é recompensado por variar.
3. **Sistemas conectados**: uma missão no Cais aumenta a vigilância local, irrita a Frente dos Armazéns, pode gerar retaliação contra seu negócio no Cais e muda a economia do bairro.
4. **Várias formas de vencer**: a temporada é pontuada em 5 categorias.
5. **IA compreensível**: cada facção registra seu último movimento com o motivo ("aproveitando sua ausência", "ao perceber sua fragilidade").

---

## 3. Personagem e especializações

Atributos: **Astúcia, Força, Lábia, Influência**. Cada missão usa um atributo principal:

```
preparo = atributo_principal × 2 + soma_dos_atributos × 0,4 + nível_da_sede × 1,5
chance  = 72 + (preparo − dificuldade) × 2 − vigilância × 0,35 − vigilância_local × 0,3
          − risco_do_bairro − risco_dos_eventos − 6 × repetições_hoje + carreira + dica
          (limitada a 8–95%)
```

Treino: +2 pontos (+1 acima de 25), 22 de energia, custo `250 + 40·nível + 1,2·nível²`,
no máximo **3 por dia**. Missões bem-sucedidas têm 30% de chance de dar +1 no
atributo usado.

### Especializações (escolha por temporada)

| | Passiva | Desvantagem | Nível 1 (10 XP) | Nível 2 (25 XP) | Nível 3 (45 XP) |
|---|---|---|---|---|---|
| **Operador** | +6 de chance; +8% de recompensa em serviços grandes (dificuldade ≥ 33); falhas custam 30% menos caixa | vigilância gerada +10%; negócios −10% | Rota de fuga: −15 na detenção | Ritmo de rua: fadiga de repetição pela metade | Sangue frio: vigilância pesa metade; cofre com Astúcia 18 |
| **Articulador** | +30% de influência; +8 em diálogos; +5 em disputas e confrontos | recompensas de missões −10% | Rede de contatos: contatos −30% | Mediador: tréguas de 5 dias, alianças −40% | Voz do bairro: tributo +60%, 50% das retaliações evitadas |
| **Empreendedor** | negócios +25% de renda e −12% de custo | chance nas missões −3 | Contador: taxa bancária 1% | Fornecedores: crises e extorsões pela metade | Sócio oculto: banco rende 0,4%/dia (até R$ 120) |

XP: o Operador ganha com missões (2 nas difíceis); o Articulador com contatos,
diálogos, tréguas, alianças e notícias; o Empreendedor com dias de renda de
R$ 150 ou mais e compras de negócios.

---

## 4. Missões

13 missões: 8 gerais e 5 exclusivas de bairro. Cada uma tem atributo, dificuldade,
energia, faixa de recompensa, vigilância pessoal e local, respeito, chance de
detenção, perda de caixa na falha e atrito com a facção local.

| Missão | Atributo | Desbloqueio | Energia | R$ base | Particularidade |
|---|---|---|---|---|---|
| Serviço suspeito | Astúcia | 0 | 16 | 150–290 | Entrada |
| Rolo na feira | Lábia | 6 resp. | 18 | 190–340 | Pouca vigilância |
| Mercadoria desaparecida | Força | 0 | 23 | 300–560 | |
| Cobrança atrasada | Força | 20 | 26 | 420–740 | |
| Operação no depósito | Astúcia | 32 | 32 | 580–980 | |
| Leilão clandestino | Lábia | 50 + 25 de influência local | 30 | 680–1120 | Exige base no bairro |
| Comboio misterioso | Força | 75 + gangue | 40 | 1050–1750 | |
| O grande cofre | Astúcia | 120 + Astúcia 22 | 52 | 1900–3100 | 1 vez por dia |
| Esquema do camelódromo | Lábia | Centro, 10 | 22 | 330–560 | |
| Carga sem dono | Força | Cais, 15 | 28 | 560–900 | Atrito alto com os Armazéns |
| Favor de vizinhança | Influência | Jardim, 0 | 18 | 90–170 | +4 de influência local |
| Galpão desativado | Astúcia | Industrial, 40 | 36 | 900–1500 | Vigilância local +16 |
| Bastidores do baile | Lábia | Vila, 12 | 22 | 300–520 | +25% em dias de festa |

**Recompensa** = sorteio × (1 + bônus do bairro + eventos + 12% se você lidera + 10% em território aliado) × economia local × (1 − 12% por repetição no dia, mínimo 50%).

**Falha**: perde uma % do caixa **em mãos**, ganha vigilância extra e pode ser detido.
A chance de detenção é `base + Procurado × 0,2 + vigilância_local × 0,15 − olheiros − defesa − fuga − 3 por proteção e por veículo equipados + 10 com Procurado 60+ − perk` (v1.5; a base sai do degrau e do tipo, ver "Roubos procedurais").
A detenção dura 1 a 3 dias (+1 com vigilância ≥ 70) e pode ser encerrada com
**fiança** (`250 + 250 × dias + 1,5 × respeito`).

**Respeito decrescente**: missões com desbloqueio 90 ou mais pontos abaixo do seu
respeito rendem 1/3 do respeito.

Alternativas seguras: **Bico** (28 de energia, R$ 110–170, −4 de vigilância) e
**Ficar na sua** (18 de energia, −20 de vigilância pessoal e −10 local).

---

## 5. Bairros e território

Cada bairro tem **economia** (60–140%, flutua diariamente e reage a eventos e
conflitos), **vigilância local** (sobe com missões, operações e confrontos; cai 10
por dia) e **presença de cada facção** (0–100).

**Liderar** = sua influência ≥ 60 e ≥ maior presença + 10.

| Bairro | Bônus / risco | Tributo/dia | Vantagem de liderar |
|---|---|---|---|
| Centro Antigo | 0 / 0 | 110 | Diálogos +8; contatos −20% |
| Cais do Norte | +15% / +5 | 140 | Operações coletivas +20% |
| Jardim União | −10% / −4 | 70 | Recrutar −25%; ânimo +2/dia |
| Distrito Industrial | +28% / +10 | 160 | Todos os negócios +12% |
| Vila das Palmeiras | +4% / −2 | 90 | Vigilância −5 extras por dia |

**Custos de liderar**: cada bairro liderado soma +2 de vigilância por dia, as
facções o consideram alvo valioso, e sua influência cai 1 por dia nos bairros
onde você não está.

**Ações de influência**: *Criar contatos* (R$ 180, 22 de energia, até 2 por bairro
ao dia, o segundo rende metade) e *Disputar área* (R$ 320, 33 de energia, exige 20
de influência, bloqueada por acordo, chance baseada em Influência, sede,
negociadores, vigilância e força da facção).

---

## 6. Economia

| Item | 0.4 | 0.5 | Motivo |
|---|---|---|---|
| Depósito | grátis | taxa de 3% (1% com perk) | Proteger dinheiro passa a ser uma decisão (E1) |
| Negócios | retorno em ~15 dias, sem risco | retorno em ~18–19 dias; renda × economia × eventos × facções; revenda a 60% | E5 e B4 |
| Contatos | ilimitados, +2 de respeito | 2 por bairro ao dia, +1 de respeito | E4 |
| Operação coletiva | ilimitada | 1 por dia, mínimo de 2 integrantes | E3 |
| Treino | linear | superlinear, 3 por dia | Evita disparo dos atributos com caixa alto |
| Manutenção da equipe | R$ 25/integrante | R$ 20 + R$ 8 × nível | Integrantes melhores custam mais |
| Tributo | — | por bairro liderado | Recompensa territorial em dinheiro |
| Sociedades (notícia) | — | R$ 800 → R$ 95/dia por 10 dias | Investimento de prazo médio |

Negócios ficam num bairro: Bar (Vila), Oficina (Jardim), Mercadinho (Centro),
Depósito de Logística (Industrial, **novo**) e Casa de Shows (Cais). Renda reduzida
em 15% se a facção dominante do bairro for hostil e muito mais forte que você, e
cortada pela metade no dia de uma extorsão.

**Fluxo entre temporadas**: o novo personagem começa com R$ 1.900 + 5% do
patrimônio (máximo R$ 1.200) + bônus de medalhas
(30/80/200 por bronze/prata/ouro, máximo R$ 800). O teto total é R$ 4.500, o que
evita bola de neve entre temporadas.

---

## 7. Gangue e facções

### Equipe
Integrantes nomeados com função: **Músculo** (+confrontos e operações), **Olheiro**
(−detenção, −vigilância das operações) e **Negociador** (+diálogos e contatos).
Sobem do nível 1 ao 5 com XP de operações e confrontos. Ânimo abaixo de 25 traz
35% de chance diária de **deserção**: o integrante vai para a facção mais hostil
(que ganha força) e vazam informações (+5 de vigilância).

### Facções (IA)
Cada facção tem relação, tensão, **força**, **rancor**, acordos e personalidade:

| Facção | Perfil | Comportamento |
|---|---|---|
| Círculo da Esquina | Tradicional | Honra acordos; retalia com **extorsão** de negócios no seu território |
| Frente dos Armazéns | Expansionista | Expande e ataca sua influência; testa quem parece fraco |
| Coletivo Aurora | Oportunista | Avança onde você **não está**; retalia com **denúncia** (vigilância); pode **trair** acordos se você parecer fraco |

Todo dia cada facção (em ordem aleatória) escolhe por sorteio ponderado entre:
**expandir** (o alvo é escolhido pela utilidade: tributo, economia, sua ausência e o
próprio território), **consolidar** (ganha força), **retaliar** (só se hostil:
relação ≤ −30 e tensão ≥ 35; no máximo uma por dia), **guerrear** contra a facção
inimiga (abre o evento "Guerra entre facções", com brecha de +12 para disputas) e
**propor acordo** (relação ≥ 30; vira uma notícia de decisão).

A **traição** é verificada antes: facções oportunistas com acordo podem rompê-lo
se você estiver fraco (equipe < 3, ânimo < 35, vigilância ≥ 70 ou poder < metade
do delas). A chance é de 4% por sinal de fraqueza × oportunismo.

Dinâmica natural: a tensão cai 1 ou 2 por dia; a relação volta ao padrão do grupo
sem acordo; a força tende a `30 + presença_total/4`.

### Acordos
- **Trégua**: relação +35, R$ 400 + R$ 200 por trégua anterior com o mesmo grupo, 24 de energia; dura 3 dias (5 com perk); exige carência de 2 dias para renovar. Agir no território do grupo durante a trégua desgasta a relação, e abaixo de 15 ele encerra o acordo.
- **Aliança** (uma por vez): relação +60, sede nível 2, R$ 900, 20 de energia. Dá +10% nas missões e nenhum atrito no território dele, e +8 contra o inimigo dele. Custa contribuição diária (`50 + 15 × sede`) e o inimigo do aliado fica mais hostil. Pedidos de apoio chegam como notícia; recusar custa −20 de relação.
- **Romper acordo**: −40 de relação, +3 de rancor e −8 com **todas** as facções; cada traição reduz 5 pontos dos diálogos futuros (até −20).

**Rival histórico**: a facção com rancor ≥ 3 ao fim da temporada começa a próxima
com −25 de relação e +15 de tensão.

---

## 8. Eventos dinâmicos

| Evento | Quando | Efeito concreto |
|---|---|---|
| **Carnaval** | dias 9–11 (fixo) | Centro e Vila +25% nas missões; Bar +60%; Casa de Shows +80%; vigilância gerada −10%; ânimo +3/dia |
| **Clássico no estádio** | dia 20 (fixo) | Bar +100%, Casa de Shows +40%, risco +8 no Centro, ânimo +5 |
| Arraial no Jardim União | aleatório, 2 dias | Missões no Jardim +20%, economia local em alta |
| Crise no comércio | aleatório, 4 dias | Negócios −25%, missões −8%, bicos −20%, recrutar −30% |
| Operação policial em {bairro} | aleatório, 2 dias | +35 de vigilância local, risco +15 |
| Greve no porto | aleatório, 3 dias | Economia do Cais −30%; a Frente dos Armazéns perde força |
| Guerra entre facções | disparado pela IA | Disputas e confrontos +12 no bairro |
| Feriadão, Eleição, Temporal, Semana de comércio, Fiscalização, Festival, Patrulhas | aleatórios | Energia, influência, risco ou renda |

No máximo um evento aleatório por vez, sem repetir o anterior. Crises não começam
depois do dia 25.

Notícias de decisão (a cada 3 dias, ou quando uma facção propõe acordo): 10 tipos,
com condições (por exemplo, "Integrantes reclamam" só com ânimo < 50, "Seu
aliado pede apoio" só com aliança).

---

## 9. Temporada e competição

- 30 dias jogáveis = **29 viradas**. A renda entra ao virar o dia; o dia 30 é o último para agir e permite encerrar. Verificado no teste "29 viradas levam ao dia 30".
- ~~**Meta**~~ (saiu na v1.5; histórico) (escolha até o dia 5; fica travada como cumprida no momento em que é atingida): Patrimônio R$ 18.000, Renome (130 de respeito e 25 missões), Territórios (12 dias liderando), Diplomacia (3 acordos e 2 relações +50) e Bonde forte (5 integrantes e 8 operações).
- **Pontuação** em 5 categorias com medalhas (bronze / prata / ouro):

| Categoria | Medida | Bronze | Prata | Ouro |
|---|---|---|---|---|
| Fortuna | patrimônio | 11.000 | 17.000 | 24.000 |
| Fama | respeito ganho | 110 | 160 | 220 |
| Território | dias liderando (soma) | 10 | 25 | 45 |
| Diplomacia | acordos, aliança, dias de aliança, relações +50, menos traições | 35 | 70 | 110 |
| Gangue | operações, confrontos vencidos, níveis da equipe, sede | 40 | 90 | 140 |

  Pontos = Σ progresso por categoria (0–100) + 15 por medalha + 40 pela meta (histórico; na v1.5 o placar é só o respeito). Títulos: Aprendiz da rua, Figura conhecida, Nome respeitado, Chefão da cidade e Lenda do Submundo.
- **Ranking de poder** (simulado e identificado como tal): você contra as 3 facções.
- **18 conquistas permanentes**, **recordes** por categoria, **prestígio** (soma das medalhas) e histórico com título e medalhas.

---

## 10. Limites éticos e de conteúdo

> **Atualizado na v0.9:** o jogo passou a ser adulto (18+) por decisão do autor. Ver §16. O parágrafo abaixo é o texto original da 0.5.

Todas as ações são abstratas ("Operação no depósito", "Rolo na feira"), sem
métodos, ferramentas ou instruções aplicáveis à realidade. Bairros, facções e
pessoas são fictícios. Não há monetização.

---

## 11. Direção de arte e interface ("rua brasileira")

Objetivo: parecer um jogo de navegador clássico, não um site. Referência de
experiência: HUD permanente do personagem, lugares com cara de lugar e lista de
serviços. Nenhum layout, nome, texto ou arte de outros jogos foi copiado.

| Elemento | Metáfora brasileira | Onde |
|---|---|---|
| HUD fixo | Retrato 3×4 do personagem (boné, chapéu ou gravata conforme a carreira), barras inclinadas de Energia e Vigilância, dinheiro em destaque | Todas as telas |
| Local | Cena SVG do bairro (sobrados e camelôs, guindastes e contêineres, casas com fios e pipa, galpões e chaminés, bar com palmeiras) + **placa de rua azul esmaltada** | Início, Serviços, Bairros |
| Eventos na cena | Confete e bandeirinhas (Carnaval, festas), chuva (Temporal), giroflex (operação/fiscalização), fumaça (guerra), faixas (greve) | Cenas |
| Notícias e eventos | **Lambe-lambe**: papel rasgado colado, tipografia de cartaz | Início |
| Resultado de ação | **Cupom** serrilhado em popup, com carimbo "DEU BOM" / "DEU RUIM" e variações | Todas |
| Detenção | **Fita zebrada** | Aviso de detido |
| Missões | **Quadro de serviços**: ícone do atributo, chance em destaque, botão grande à direita (polegar) | Serviços |
| Facções | **Dossiê** em pasta parda com emblema próprio | Gangue |
| Integrantes | Cartinhas com nível, função por cor e XP | Gangue |
| Registro | **Diário** em agenda de folhas gastas; **Jornal do Submundo** na Rua | Início |
| Virada do dia | Amanhecer de 1 segundo com "Dia N" | Global |
| Capa | Logo pintado + faixa verde-amarelo-azul sobre a cena do Centro | Tela inicial |

Regras: fundo de asfalto/concreto com âmbar; papel creme para o que é "do
mundo" (cartaz, cupom, dossiê, diário); botões com relevo e sombra dura; títulos
em caixa alta condensada (`Impact` → `Roboto Condensed` → sans); tudo em CSS e SVG
inline, sem arquivos externos. Animações curtas e desligadas com
`prefers-reduced-motion`. Na v1.5 o cupom de resultado pula num popup no
centro da tela, então o aviso flutuante não é mais usado para resultados.

---

## 12. Cidades (v0.6)

O jogador escolhe uma de seis **cidades reais**. A cidade troca nomes de bairros,
grupos, negócios e festas, e dá uma vantagem própria. Bairros e grupos são
**inventados**, inspirados na paisagem de cada cidade, para não associar
comunidades reais ao crime. As regras dos bairros (seção 5) valem por papel:
centro comercial, zona de cargas, bairro residencial, polo industrial e zona boêmia.

| Cidade | Vantagem | Centro · Cargas · Residencial · Industrial · Boemia | Grupos (tradicional · expansionista · oportunista) |
|---|---|---|---|
| Rio de Janeiro | Carnaval de 4 dias; serviços na orla +10% | Largo dos Arcos · Cais da Guanabara · Parada do Subúrbio · Galpões da Avenida · Praia do Posto 13 | Velha Guarda do Largo · Turma do Cais · Rede do Calçadão |
| São Paulo | Negócios +8% | Ladeira dos Camelôs · Terminal de Cargas · Vila dos Sobradinhos · Galpões da Marginal · Quadra da Garoa | Irmandade da Ladeira · Consórcio dos Galpões · Rede Garoa |
| Belo Horizonte | Boteco +40%; diálogos +4 | Mercado Velho · Pátio Ferroviário · Alto da Serra · Polo do Minério · Rua dos Botecos | Confraria do Mercado · Turma do Trilho · Rede das Gerais |
| Salvador | Carnaval de 5 dias; equipe +1 de ânimo/dia | Largo das Ladeiras · Cais da Baía · Alto das Mangueiras · Polo do Recôncavo · Orla do Dendê | Irmandade das Ladeiras · Estiva da Baía · Rede do Dendê |
| Recife | Viagem pela metade do preço e sem energia | Pátio dos Sobrados · Cais das Pontes · Beira do Mangue · Galpões da BR · Ladeira dos Bonecos | Clube do Pátio · Frente das Pontes · Maré Mansa |
| Porto Alegre | Treinos −10% | Largo do Mercado · Cais do Guaíba · Vila dos Plátanos · Distrito das Chaminés · Rua da Boemia | Velhos do Mercado · Turma do Guaíba · Rede Minuano |

Cada cidade também nomeia o Carnaval ("Carnaval dos trios", "Carnaval do frevo"),
o clássico de futebol ("Clássico mineiro") e a festa do serviço da zona boêmia
(baile, pagodão, brega, forró). Nas cenas, uma silhueta distante identifica a
cidade (morros, torres, serra, elevador, pontes, chaminé).

Saves antigos mantêm a cidade que já tinham; uma cidade desconhecida vira Rio de Janeiro.

## 13. Primeiros passos e orientação (v0.6)

Três camadas respondem "qual é o objetivo, aonde chegar e como":

1. **Como jogar**: introdução de 4 páginas aberta no primeiro jogo (O objetivo, Seu dia, Os riscos, Sua cidade), sempre acessível depois.
2. **Primeiros passos**: trilha de 8 passos com recompensas pequenas (R$ 520 no total). O passo atual aparece em todas as telas, com um botão que leva à tela certa, e a aba correspondente pisca. Pode ser dispensada.

| # | Passo | Recompensa |
|---|---|---|
| 1 | Escolher a especialização | — |
| 2 | Fazer o primeiro serviço | R$ 80 |
| 3 | Treinar um atributo | R$ 60 |
| 4 | ~~Escolher a meta da temporada~~ (saiu na v1.5) | — |
| 5 | Virar o dia | R$ 60 |
| 6 | Criar contatos no bairro | R$ 80 |
| 7 | Guardar dinheiro no banco | R$ 40 |
| 8 | Chegar a 30 de respeito e fundar a gangue | R$ 200 |

3. **Seu rumo**: cartão permanente no Início com a pontuação, o título atual, o próximo título e a **medalha mais próxima**, com a dica de como chegar nela. Avisa na reta final (dia 25 em diante).

Para não sobrecarregar, a primeira notícia só aparecem depois da escolha da especialização.

---

## 14. Feira do Rolo, Galpão, vida noturna e Perfil (v0.7)

Mecânicas clássicas do gênero (arsenal, mercadoria, produção, remessa, noite e
ficha do personagem) com sistemas e nomes próprios. Tudo é comércio abstrato:
comprar, produzir, transportar e vender, sem receitas nem métodos reais.
Prostituição não entra como mecânica; a noite é feita de bares e casas noturnas.

### Navegação
Cinco abas: **Início, Serviços, Cidade, Gangue, Perfil**. A aba Cidade reúne os
lugares (Bairros, Galpão, Feira do Rolo, Vida noturna, Banco e negócios,
Temporada). Temporada também é acessível pelo Perfil.

### Feira do Rolo (equipamentos)
Um item por espaço; ao trocar, o antigo volta por 50%.

| Espaço | Itens (preço · respeito) | Efeito |
|---|---|---|
| Arma | Soco-inglês (300 · 0), Peixeira (750 · 15), Três-oitão (1.700 · 35), Pistola (3.300 · 70), Doze (5.600 · 110), Fuzil (9.200 · 160) | Poder 2/4/7/10/13/17: confrontos +poder, operações +60% do poder, serviços de Força +50% do poder. **Custo:** com arma de fogo (poder ≥ 7), +1 dia de detenção |
| Proteção | Jaqueta de couro (400 · 0), Colete usado (1.500 · 30), Colete tático (4.200 · 90) | Defesa 2/5/9: reduz a chance de detenção |
| Veículo | Bicicleta cargueira (250), Cinquentinha (950 · 10), Moto 150 (2.400 · 40), Opala preto (5.200 · 80), Carro blindado (12.000 · 150) | Carga +10/15/25/60/90; fuga 1/3/6/8/12 (detenção e blitz); da Moto em diante, viajar não gasta energia |

### Galpão (mercadorias)
| Mercadoria | Base | Risco | Respeito |
|---|---|---|---|
| Cigarro da fronteira | R$ 20 | 1 | 0 |
| Bebida batizada | R$ 45 | 1 | 10 |
| Erva | R$ 70 | 2 | 20 |
| Eletrônico sem nota | R$ 120 | 2 | 30 |
| Bala | R$ 160 | 3 | 60 |
| Pó | R$ 300 | 4 | 100 |

- **Preço** = base × fator do bairro (60–150%), que oscila todo dia e volta aos poucos a 100%. A venda paga 95% do preço (+5% em território aliado).
- **Impacto**: cada unidade negociada move o preço local (mais forte nas mercadorias caras), então comprar e revender no mesmo lugar dá prejuízo.
- **Custos e riscos**: 3 de energia por negócio; vigilância pessoal e local sobem com a quantidade e o risco; vender na área de outro grupo gera atrito.
- **Carga**: 30 + veículo + 40 por ponto de produção.
- **Blitz**: viajar carregado tem chance de `carga×risco/12 + vigilância×0,25 − fuga` (máx. 60%) de perder metade da carga.
- **Comprador de fora**: a cada 5 dias (5, 10, ... 30), no bairro de cargas, paga **1,9× a base** por uma mercadoria anunciada com antecedência, até 60 unidades, uma vez por dia. É a mecânica de planejamento: guardar estoque para a data certa.
- **Produção própria** (3 níveis: ×1, ×1,8, ×2,6; custo de R$ 30 por nível ao dia):

| Ponto | Produz | Custo · respeito |
|---|---|---|
| Alambique de fundo de quintal | 7 Bebida/dia | R$ 2.000 · 15 |
| Plantação na mata | 6 Erva/dia | R$ 3.600 · 35 |
| Laboratório de galpão | 4 Bala/dia | R$ 7.000 · 80 |

  **Batida policial**: com vigilância acima de 40, cada ponto tem `(vigilância − 40) × 0,5%` de chance por dia (máx. 25%) de ser fechado por 2 dias, perdendo o estoque daquela mercadoria.
- **Patrimônio** passa a contar estoque (70% da base), equipamentos e produção (50% do custo).
- **Sexta categoria de medalha, Comércio**: lucro com mercadorias (vendas e remessas menos compras). Bronze R$ 3.000, prata R$ 7.000, ouro R$ 12.000.

### Vida noturna
Dinheiro vira energia hoje; a ressaca reduz a energia recuperada amanhã. Até 2
saídas por dia; a segunda custa 50% a mais.

| Lugar | Custo | Energia | Ressaca | Extra |
|---|---|---|---|---|
| Boteco | R$ 60 | +12 | −3 | — |
| Baile (nome muda por cidade) | R$ 160 | +25 | −6 | equipe +3 de ânimo; +2 de vigilância |
| Inferninho | R$ 360 | +40 | −10 | 55% de fazer contatos (+influência); senão, 40% de confusão (+6 de vigilância) |

### Perfil
Ficha do personagem: retrato, título, atributos em barras, os três espaços de
equipamento, números da temporada (serviços, detenções, mercadoria vendida,
remessas, blitze) e acesso a Temporada e Como jogar.

---

## 15. Saúde, hospital e duelos de rua (v0.8)

### Saúde (0–100, barra azul no topo)
- **Cai** em: derrota em confronto (12–22), derrota em duelo (14–26 + poder do adversário ÷ 10), vitória em duelo (3–9), falha em serviço de Força (6–12) e falha em operação coletiva (4–9). A **proteção reduz o dano** em 60% da sua defesa.
- **Efeito**: abaixo de 60, todas as chances (serviços, operações, confrontos, duelos) caem `(60 − saúde) × 0,4` pontos. Abaixo de 25 você fica **ferido**: não confronta, não lidera operação e não duela.
- **Internação**: ao chegar a 0, você fica 2 dias internado, a saúde volta a 35, paga até R$ 300 de conta e a vigilância cai 10. Internado, não faz nada físico (serviços, treinos, viagens, duelos, noite, Galpão, contatos, disputas); banco, notícias e decisões continuam. Recupera +15 por dia internado.
- **Recuperação**: +10 por dia (+6 se detido).

### Hospital
| Atendimento | Custo | Efeito |
|---|---|---|
| Posto de saúde | 20 de energia, 1 vez por dia | +25 de saúde |
| Clínica particular | R$ 12 por ponto que falta | saúde cheia na hora |

### Duelos de rua
Até 3 por dia, 15 de energia cada. Adversários são personagens inventados:

| Adversário | Poder | Respeito exigido | Prêmio | Respeito |
|---|---|---|---|---|
| Zé Marrento | 12 | 0 | R$ 80–160 | 1 |
| Tonhão da Feira | 22 | 10 | R$ 150–280 | 2 |
| Cabeça de Bagre | 30 | 20 | R$ 220–400 | 2 |
| Mãozinha | 40 | 35 | R$ 320–560 | 3 |
| Galego do Fliperama | 52 | 55 | R$ 450–800 | 4 |
| Sargento Bigode | 64 | 80 | R$ 650–1.100 | 5 |
| Carcará | 78 | 110 | R$ 900–1.500 | 6 |
| Rei do Pedaço | 95 | 150 | R$ 1.400–2.300 | 9 |

- **Seu poder de luta** = Força × 1,6 + Astúcia × 0,6 + poder da arma × 1,8 + defesa + sede × 1,5. Iniciante sem equipamento: 10.
- **Chance** = 50 + (seu poder − poder do adversário) × 2,2 − penalidade de saúde − 4 por duelo já feito no dia (8–92%).
- **Vitória**: prêmio, respeito (dobrado na primeira vitória contra cada adversário), 25% de chance de +1 de Força e um pouco de dano. **Derrota**: 5% do caixa em mãos e dano maior.
- **Custo**: +1 de vigilância por duelo (+4 com arma de fogo) e +3 de vigilância local.
- É o uso direto das armas e proteções da Feira do Rolo.
- Conquistas novas: **Nome na roda** (10 vitórias) e **Destronou o rei** (vencer o Rei do Pedaço).

---

## 16. Linha adulta: arsenal, serviços, noite e cadeia (v0.9)

O jogo é **18+**: crime, armas, drogas e linguagem pesada, com aviso obrigatório
na capa (caixa de confirmação) e, para quem já jogava, um aviso único na primeira
abertura. A linha que permanece: **nenhum texto ensina a fazer** algo no mundo real.

### Arsenal (Feira do Rolo)
Itens antigos mantêm o código interno (saves continuam válidos); alguns só mudaram de nome.

| Arma | Preço · respeito | Poder | Observação |
|---|---|---|---|
| Pedaço de pau com prego | 120 · 0 | 1 | |
| Chave de fenda amolada | 300 · 0 | 2 | antes "Soco-inglês" |
| Vergalhão de obra | 500 · 8 | 3 | |
| Facão | 750 · 15 | 4 | antes "Peixeira" |
| Maquita | 1.200 · 25 | 5 | libera "Caixa eletrônico na maquita" |
| Três-oitão raspado | 1.700 · 35 | 7 | primeira arma de fogo: libera a lotérica |
| Pistola .40 | 3.300 · 60 | 9 | |
| Doze de cano serrado | 4.800 · 80 | 11 | |
| Uzi de pente estendido | 6.500 · 100 | 13 | |
| Submetralhadora | 8.000 · 115 | 14 | |
| FAL 7.62, o Vovô | 9.200 · 130 | 16 | |
| Fuzil AR-15 | 12.000 · 150 | 18 | pesada |
| Ponto Cinquenta | 18.000 · 175 | 21 | pesada |
| Metralhadora MAG | 24.000 · 200 | 24 | pesada |
| Lança-rojão | 30.000 · 220 | 26 | pesada |
| Fuzil dourado de tambor duplo | 30.000 · 150 | 26 | pesada; **troféu**: só depois de vencer o Rei do Pedaço (não se compra vantagem) |

- Arma de fogo (poder ≥ 7): +1 dia se for preso; +4 de vigilância por duelo.
- **Arma pesada**: +3 de vigilância todo dia enquanto estiver equipada.

| Proteção | Preço · respeito | Defesa |
|---|---|---|
| Lista telefônica com silver tape | 150 · 0 | 1 |
| Camisa de time na cara e jaqueta de couro | 400 · 0 | 2 |
| Colete de vigilante vencido | 1.500 · 30 | 5 |
| Colete de kevlar da polícia | 2.800 · 60 | 7 |
| Colete tático com placa de cerâmica | 4.200 · 90 | 9 |
| Traje tático com escudo balístico | 8.000 · 140 | 12 |

### Serviços renomeados e novos
- Renomeados (mesmas regras): Bater carteira, Celular no ponto de ônibus, Mercadinho Dois Irmãos, Caminhão de carga na rodovia, Carro-forte na serra.
- Novos: **Fiação de cobre** (Astúcia, fácil), **Barraquinha de pastel** (Força, fácil), **Clonar cartão de velho rico** (Lábia, 40 de respeito), **Caixa eletrônico na maquita** (Astúcia, 45, exige arma de poder 5) e **Casa lotérica** (Força, 60, exige arma de fogo). As recompensas foram calibradas para não inflar o farm (ver VALIDATION).

### Noite
| Lugar | Custo | Energia | Ressaca | Extra |
|---|---|---|---|---|
| Boteco do Zé | R$ 40 | +12 | −3 | — |
| Pagode na laje | R$ 120 | +22 | −5 | equipe +4; 60% de firmar contatos (+influência) |
| Baile de favela | R$ 160 | +38 | −8 | equipe +3; +2 de vigilância; **22% de briga com gangue rival (fere)** |
| Termas VIP | R$ 900 | energia cheia | −4 | exige 60 de respeito; sem risco; negócio fechado com quem manda no bairro (relação +5) |

### Hospital e cadeia
- **UPA** (antes posto de saúde) e **Propina pro plantonista** (antes clínica): mesmas regras.
- **Advogado de porta de cadeia** (antes fiança): sai na hora, garantido.
- **Molhar a mão do carcereiro**: 45% do preço do advogado, uma tentativa por dia; chance `55 + Lábia − vigilância × 0,3` (15–85%). Se der errado, +1 dia e +8 de vigilância.

---

## 17. Assaltos do bando em etapas (v1.0)

Na aba Gangue, **Assaltos do bando**. Um plano por vez, em quatro etapas:

1. **Planejar** (15 de energia): paga o plano. Se faltar gente, contrata até 4 **avulsos** (mais fracos, pagos na hora). O plano vale do dia seguinte até 5 dias depois; se o prazo passar, esfria (−5 de ânimo).
2. **Reconhecer o terreno** (15 de energia, 1 vez por dia): +12 de informação (+2 por nível de Olheiro, até +10), teto 40. Cada ponto vale +0,5% de chance. Sobe 4 de vigilância local.
3. **Executar** (40 de energia, a partir do dia seguinte ao plano): exige o bando completo, ânimo ≥ 30, não estar ferido e a arma do líder com o poder mínimo.
4. **Dividir**: o bando fica com 25%; o resto é seu.

- **Poder do bando** = seu poder de luta + 3 × níveis dos integrantes + 2 × integrantes + 2 × níveis de Músculo + 4 × avulsos.
- **Chance** = 40 + (poder − dificuldade) × 1,2 + informação × 0,5 + (ânimo − 50) × 0,15 − vigilância × 0,3 − penalidade de saúde − risco do evento ÷ 2 (5–90%).
- **Sucesso**: dinheiro × economia do bairro, respeito, vigilância, ânimo +6, XP para todos.
- **Fracasso**: −10% do caixa em mãos, vigilância alta, ânimo −15, ferimento, 35% de um integrante "rodar" (sai do bando) e chance de prisão de 2 a 3 dias (+1 com arma de fogo).
- Depois de executar, o bando **esfria 3 dias** antes de novo plano. Cada assalto vira atrito com o grupo que manda no bairro e +25 de vigilância local.
- Cada assalto certo vale **+15 na categoria Gangue**. Conquistas: **Primeiro assalto** e **Golpe do ano** (Cofre central).

| Assalto | Bando | Sede | Arma | Respeito | Dificuldade | Plano · avulso | Rende | Prisão |
|---|---|---|---|---|---|---|---|---|
| Arrastão no shopping | 3 | 1 | 3 | 30 | 50 | R$ 400 · 300 | R$ 2.200–3.600 | 30% |
| Bloqueio na rodovia | 5 | 2 | 9 | 55 | 80 | R$ 900 · 450 | R$ 5.000–8.000 | 36% |
| Agência no interior | 6 | 3 | 13 | 80 | 110 | R$ 1.600 · 600 | R$ 9.000–14.000 | 42% |
| Carro-forte na serra | 8 | 4 | 16 | 105 | 140 | R$ 2.600 · 800 | R$ 15.000–22.000 | 46% |
| Base da transportadora de valores | 10 | 5 | 18 | 130 | 170 | R$ 4.000 · 1.000 | R$ 24.000–34.000 | 50% |
| Cofre central | 12 | 6 | 21 | 155 | 200 | R$ 6.000 · 1.300 | R$ 38.000–52.000 | 55% |

O serviço solo que se chamava "Carro-forte na serra" passou a se chamar **Cofre da joalheria** (mesmas regras), para não confundir com o assalto do bando.

---

## 18. Arte ilustrada (v1.1)

- **SVG em código** (`src/art.js`): cena para cada lugar da Cidade (Bairros, Galpão, Feira do Rolo, Vida noturna, Duelos, Hospital, Banco, Temporada) e para Assaltos do bando; retrato de busto para os 8 adversários de duelo; cena para os 6 assaltos, também no cartaz do plano em andamento. Itens bloqueados aparecem dessaturados.
- **Imagens pintadas opcionais**: arquivos em `art/` com as chaves `place-<id>`, `rival-<id>` e `heist-<id>` substituem o SVG correspondente no build. As que faltarem continuam em SVG. Guia de estilo e prompts em `PROMPTS_ARTE.md`.
- **v1.4**: as 24 imagens pintadas estão no jogo, e Galpão, Duelos, Hospital, Assaltos, Banco e Temporada ganharam cena no topo.
- **Retrato do jogador (v1.4)**: no Perfil, o jogador escolhe 1 de 10 retratos (Malandro, Funkeira, Motoboy, Sertanejo, Gaúcho, Coroa, Skatista, Capoeirista, Golpista, Marombeiro) ou volta à silhueta da classe. É só aparência: grátis, sem efeito nas regras, guardado no save (`avatar`) e mantido na temporada seguinte. Imagens `art/avatar-<id>`.

---

## 19. O ciclo do jogo e a organização das telas (v1.2)

Baseado no fluxo descrito pelo autor: **um ciclo rápido de ambição**.

```
Roubar (gasta energia) → dinheiro, atributos e respeito
   ↓ acabou a energia
Noite (dinheiro vira energia; ressaca amanhã)
   ↓ bolso cheio
Feira do Rolo (arma melhor) → roubo maior
   ↓ sem energia e sem saída
Dormir (vira o dia: +70 de energia, renda, grupos se movem)
```

### Fases (por respeito)
| Fase | Respeito | O que entra |
|---|---|---|
| Pé de chinelo | 0 | Roubar, Noite, Feira, Treino, Banco e negócios, Hospital |
| Subindo no movimento | 30 | Bando e assaltos (30); antes disso: Duelos (10), Galpão (15), Bairros (20) |
| Linha de frente | 90 | Assaltos grandes e arma pesada |
| Dono do crime | 150 | Os maiores golpes |

A fase aparece na barra do personagem. Lugares ainda fechados aparecem **trancados, com o respeito que falta**. Quem já fechou uma temporada vê tudo aberto.

### Navegação
- Abas na ordem do ciclo: **Rua, Roubar, Noite, Feira, Cidade**.
- **Rua**: cena do bairro, dia e fase, botão Dormir, o cartão **"E agora?"**, os quatro passos do ciclo, notícia, rumo e diário.
- **"E agora?"** escolhe o próximo passo pelo estado, nesta ordem: saúde baixa → Hospital; vigilância alta → ficar na sua; dinheiro para arma que destrava roubo → Feira; sem energia → Noite (se houver saída e dinheiro) ou Dormir; senão, o melhor roubo. Enquanto os primeiros passos estiverem ativos, só o guia fala.
- **Cidade**: Bando e assaltos, Banco e negócios, Galpão, Bairros, Duelos, Hospital, Perfil e temporada.
- **Perfil** abre tocando no retrato da barra do personagem.

### Regras que mudaram para sustentar o ciclo
- **Arma libera roubo**: Cobrança (poder 2), Mercadinho e Carga sem dono (4), Galpão desativado e Caixa eletrônico (5), Lotérica e Caminhão na rodovia (7), Cofre da joalheria (9).
- **Arma melhor vale a pena**: roubo armado paga +15%, e cada ponto de poder acima do mínimo dá +1,5 de chance (até +10).
- **Noite**: 3 saídas por dia (antes 2); cada saída a mais custa +50%. Dono do **Bar** bebe de graça no Boteco; dono da **Casa de Shows** não corre risco de briga no Baile.
- **Primeiros passos** na ordem do ciclo (8 passos): especialização, primeiro roubo, primeira arma, noitada, treino, dormir, banco, bando.

### O que do fluxo do autor depende de servidor (não existe nesta versão)
- Outros jogadores no bando, caçada a jogadores na noite e ranking nacional. Hoje: integrantes e grupos rivais simulados; a "emboscada" na noite é a briga do Baile.
- Renda por hora de relógio. Hoje: renda ao dormir.

---

### Rua e topo (v1.4)

- **Nomes**: a vigilância pessoal (`heat`) aparece ao jogador como **Procurado**; a do bairro (`vigil`) como **Polícia no bairro** ("Polícia" na placa); a economia do bairro como **Grana**. As regras e os números não mudaram, só o nome.
- **Topo (v1.5)**: dinheiro grande e, logo abaixo, o **respeito com estrela** (é o que conta no ranking) e o dia. Barras com ícone; Energia e Saúde grossas, Procurado e Vício finas e apagadas, que acendem com borda âmbar (Procurado ≥ 30, Vício ≥ 40) e vermelha piscando (Procurado ≥ 60, Vício ≥ 70).
- **Topo com 4 barras**, em duas linhas no celular: Energia e Saúde (o que você tem) em cima, Procurado e Vício (o que te ameaça) embaixo. O Vício pisca a partir de 70, quando começa o risco de overdose.
- **Tela Rua (v1.5)**, de cima para baixo: placa do bairro com **só a sua influência** ali (tocar no "?" explica a influência, o que ela libera, quanto falta para mandar, e mostra Dono, Grana e Polícia) → primeiros passos ou "E agora?" (a ação vem primeiro) → faixa do dia com **Dormir discreto**, que só fica em destaque com menos de 16 de energia → lambe-lambe "Hoje na cidade" → notícia com decisão → **Sua temporada** em 4 blocos (patente, classe, mês, feitos do mês) com atalhos para Medalhas e Habilidades (no Perfil) → diário com 2 registros.

### Um placar só: o respeito (v1.5)

Os pontos da temporada saíram. O **respeito** é o placar do mês, o ranking online e a **patente** (o antigo título, de Aprendiz da rua a Lenda do Submundo, sumiu). As medalhas viraram **feitos do mês**: chegar a bronze, prata e ouro em Fortuna, Território, Diplomacia, Gangue e Comércio paga **+6, +10 e +14 de respeito** na hora, uma vez por nível (a Fama saiu, porque era o próprio respeito). A **meta da temporada saiu** (v1.5): o placar é só o respeito. Os feitos continuam dando legado para a temporada seguinte (até R$ 800). Save antigo entra com os feitos que já tinha dados como pagos.

Também na v1.5: o Assaltante passou de +20% para **+15%** de dinheiro nos roubos e nos assaltos do bando.

### Equipamento nos roubos (v1.5)

Antes, cada ponto do atributo valia +4% e a arma só +0,5% por ponto, e só nos roubos de Força. Agora o equipamento soma chance em **todo** roubo:

| Peça | Soma na chance |
|---|---|
| Arma | poder × 2 (Força), × 1,2 (Astúcia), × 0,8 (Influência), × 0,5 (Lábia) |
| Proteção | defesa × 1 nos roubos de Força e nos armados; × 0,5 nos outros |
| Veículo | fuga × 0,8 |

Assaltante: arma e proteção +15%; Dono da Noite: arma −20% nos roubos. Os roubos grandes pedem **veículo de fuga**: Caixa eletrônico (Bicicleta), Lotérica e Galpão desativado (Cinquentinha), Caminhão de carga e Cofre (Moto 150). As dificuldades subiram pela metade do equipamento esperado em cada degrau (Bater carteira 14 → 15, Mercadinho 33 → 37, Lotérica 42 → 48, Caminhão 46 → 52, Cofre 58 → 64), então o equipamento dá vantagem líquida. Para compensar o dinheiro que vira equipamento, a medalha de Fortuna foi a 6.000 / 9.000 / 13.000 e a meta Patrimônio a R$ 9.000. Cada roubo mostra "Seu equipamento: +X% de chance".

### Roubar em sequência sem virar hóspede da cadeia (v1.5)

Com arma, proteção e veículo, roubar seguido no segundo dia dava 8% a 20% de cadeia por tentativa. Agora:

- **Só de estar equipado** já soma chance: arma +3, proteção +2, veículo +2 (além da conta pela qualidade acima).
- Proteção e veículo equipados tiram **3 cada** da chance de ser preso, além da defesa e da fuga.
- Roubos pequenos (sem exigência de arma) têm a detenção-base 40% menor: Bater carteira 28 → 17, Rolo 18 → 11, Celular 38 → 23, Fiação 24 → 14, Pastel 30 → 18, Camelódromo 30 → 18, Baile 26 → 16, Clonar cartão 26 → 16, Leilão 28 → 17, Favor 10 → 6.
- Repetir o mesmo roubo no dia tira **4** de chance por vez (antes 6). O Procurado pesa 0,2 por ponto na detenção (antes 0,3).
- Iniciante com Pedaço de pau, Lista telefônica e Bicicleta, Procurado 22: Bater carteira 83% de chance e 2% de cadeia por tentativa (antes 74% e 9%); Celular no ponto 61% e 7% (antes 53% e 20%).

A fórmula da detenção passa a ser `base + Procurado × 0,2 + vigilância do bairro × 0,15 − olheiros − defesa − fuga − 3 (proteção) − 3 (veículo) − perk`, entre 5% e 90%.

### Topo: bairro, atalhos e leitura das barras (v1.5)

- **Rodapé do topo:** bairro atual (com a cor dele), dia e o botão de som. Quando o Procurado passa de 30, aparece a faixa (De olho, Na mira, Caçado).
- **Barras são atalhos:** Energia → Noite; Saúde e Vício → Hospital; Procurado → Roubar (onde ficam a propina e o "ficar na sua").
- **Energia acima de 100** (com doses): trecho dourado por cima da barra e borda dourada.
- **Procurado:** marcas nas faixas 30, 60 e 85. Procurado e Vício ficam discretos quando baixos e acendem na zona de risco.
- Patente e classe numa linha só (quebra em duas apenas se não couber), retrato menor e espaçamentos apertados: o topo foi de 154 para 128 px de altura no celular.

### Ajustes de tela e do Galpão (v1.5, pedidos do autor)

- **Roubar:** roubo sem especialidade não mostra mais "Genérico"; só golpes (com o atributo) e assaltos (arsenal) levam etiqueta.
- **Casa da noite:** um botão Sair só.
- **Trilha de compra:** saiu a frase "Primeiro compre: X" da Feira e dos Negócios; o item bloqueado aparece apagado, na ordem da prateleira. (A exigência de respeito continua escrita.)
- **Comprador de fora:** não anuncia mais o produto nem o preço. Antes do dia: "Dizem que um barco atraca no cais no dia N. Ninguém sabe o que ele vem buscar nem quanto paga." No dia, fora do cais: "Ele só fala de negócio pessoalmente." Só no cais, no dia, ele diz o que quer e quanto paga. O recado da Rua também não revela o produto.
- **Mercadorias:** só a porcentagem do preço, com a cor (verde até 90%, vermelho a partir de 112%), sem as palavras barato, normal e caro.
- **Esquemas sem custo por dia:** paga-se só para montar e ampliar (antes, R$ 30 por nível ao dia, mais a propina do Laboratório e da Refinaria).

### Bico e treino recalibrados (v1.5, auditoria)

- **Bico:** 28 de energia, **R$ 30–45**, Procurado −4. É o dinheiro seguro de quem precisa esfriar, não uma alternativa ao roubo.
- **Treino:** custo = 80 + 30 × nível + 1,6 × nível² (antes 250 + 40 × nível + 1,2 × nível²). No começo, R$ 184 a R$ 318.

### Tremor de tela (v1.5)

A tela inteira (topo e conteúdo) treme **forte** quando você é preso, enquadrado ou vai para a UTI, e **leve** quando a ação te fere (assalto que dá errado, briga na noite, overdose, desintoxicação). Meio segundo no máximo; no celular que permite, vibra junto. Não acontece com "reduzir movimento" ligado. O cupom de resultado com "DEU RUIM" continua com o seu tremor próprio.

### Apresentação para personagem novo (v1.5)

Logo depois de criar o personagem (no jogo local e no online), abre uma apresentação de 3 telas, sem contas: **Você chegou** (a cidade, o mês e o objetivo: respeito, patente e ranking), **A rua gira assim** (roubar do fácil ao difícil, a noite dá energia, a Feira abre roubos maiores, os negócios pagam todo dia) e **A rua cobra** (polícia, vício, saúde e a história na Rua). "Começar" fecha e o guia de primeiros passos segue. Não abre na virada de temporada. As páginas completas continuam em "Como jogar".

### UPA de graça e abertura com conta (v1.5)

- **UPA de graça**, uma vez por dia cada: atendimento (+25 de saúde) e **soro na veia (−50 de vício)**, sem energia nem dinheiro. O soro continua custando saúde (0,5 por ponto de vício tirado: −25 com o soro cheio).
- **Abertura com conta guardada:** o jogo mostra "Carregando seu perfil…" (com o e-mail e o botão "Entrar com outra conta") até o servidor confirmar a sessão, e só então abre o personagem online. Antes abria o save local ou a tela inicial e trocava sozinho depois. Se a sessão expirou, volta à tela inicial com o aviso.

### Bairros com identidade (v1.5, desenho com o autor)

- **Cor própria:** a cor da região onde você está tinge a borda da cena, os cartões de roubo, o dia e o título das telas. Centro âmbar (#e0a040), Cais azul de porto (#4a8fc0), Jardim verde (#5aa36a), Industrial cinza de fábrica (#8a949a) e Vila **vinho bordô** (#8a2a3a, pedido do autor).
- **Roubos com nome do lugar:** a escada é a mesma (degraus e números iguais), mas nome e texto mudam com o tipo de bairro. Exemplos: Bater carteira vira "Rapa no terminal das barcas" no Cais, "Rapa no meio do baile" na Vila, "Rapa na saída do turno" no Industrial e "Bolsa no ponto do ônibus" no Jardim. O Centro usa os nomes padrão. São 13 nomes por tipo de bairro (`LOCAL_MISSIONS`), válidos nas 6 cidades.
- **Personalidade de risco e recompensa,** com ficha curta no topo de Roubar e em cada bairro:

| Bairro | Ficha | Saque | Dificuldade | Polícia do bairro sobe | Atrito com o grupo |
|---|---|---|---|---|---|
| Centro | Paga bem · Polícia média · Grupo atento | +8% | +3% | ×1 | ×1 |
| Cais | Paga muito · Polícia fraca · Grupo perigoso | +18% | 0 | ×0,6 | ×1,6 |
| Jardim | Paga pouco · Polícia fraca · Grupo tranquilo | −12% | −6% | ×0,6 | ×0,7 |
| Industrial | Paga muito · Polícia forte · Grupo atento | +28% | +12% | ×1,5 | ×1 |
| Vila | Paga bem · Polícia média · Grupo esquentado | +5% | +4% | ×1 | ×1,3 |

- **Chegada na Rua:** uma frase do clima do bairro aparece entre as cenas do momento.
- **Viagem:** o botão diz "Comprar passagem e ir · R$ 90 · 5 energia" ("grátis" quando não custa).

### A Rua conta a história (v1.5)

Pedido do autor: a Rua é o lugar da narrativa, da emoção, das decisões e dos avisos. De cima para baixo:
1. **Placa da região** com a sua influência.
2. **Cena do momento**, como legenda da placa ("A rua agora"): um parágrafo curto, em segunda pessoa, que muda com a situação (preso, na UTI, caçado, na mira, viciado, ferido, exausto, dono do bairro) e, fora disso, com a patente. São duas variações por situação, estáveis no mesmo dia.
3. **Primeiros passos**: o passo do guia, enquanto ele estiver ativo (o "E agora?" saiu).
4. **Capítulo da história**, quando há um à espera, em papel de lambe-lambe: quem fala, o texto e duas decisões com o preço à vista.
5. **Notícia com decisão** (o sistema que já existia).
6. **Recados da rua** (até 3): caçado ou na mira, ferido, vício alto, comprador de fora no cais, plano do bando de pé, rival crescendo num bairro seu, reta final do mês. Cada recado leva à tela certa.
7. O **dia** e o botão **Dormir** ficam no topo (saiu a faixa do dia).
8. **Jornal do Submundo** (substituiu o "Hoje na cidade" e a faixa de progresso; ver "Jornal do Submundo e Diário em agenda").
9. **Diário** em forma de agenda. O rodapé ficou só no Perfil.

**Capítulos** (um por patente, no máximo um por dia; a história acompanha o personagem entre temporadas e não se repete). Personagens inventados:

| # | Patente | Capítulo | Quem | Decisão A | Decisão B |
|---|---|---|---|---|---|
| 1 | Pé de chinelo (após o 1º roubo) | O quarto dos fundos | Dona Zefa | Dar a palavra: +4 de influência | Pedir um trocado: +R$ 40, −1 de respeito |
| 2 | Rato de pista | O entregador | Miúdo | Botar na fita: R$ 60, −10 de Procurado | Mandar ficar longe: +3 de respeito |
| 3 | Linha de frente | O carro parado | Delegado Bráulio | Pagar: R$ 400, −25 de Procurado | Recusar: +6 de respeito, +15 de Procurado |
| 4 | Gerente do movimento | A proposta | O Doutor | Entregar o grupo do bairro: +R$ 1.500, relação −25 e tensão +20 | Não entregar: +8 de respeito, +8 de influência |
| 5 | Dono do morro | O topo é frio | Dona Zefa | Reformar a pensão: R$ 2.000, +15 de respeito | "Não devo nada": +3 de respeito, −10 de influência |

Cada escolha registra uma frase de consequência no diário. Ação `story(id, escolha)`; estado `story.done`.

### Menos texto, decisão à vista (v1.5)

Pedido do autor: o jogo não precisa explicar todas as contas na tela. Regra de interface: **cada cartão mostra só o que serve para decidir; a conta completa fica atrás de "Detalhes" ou em "Como jogar".**
- **Roubar:** cartão com número do degrau, nome, tipo, chance grande e fichas (saque, energia, Procurado, respeito, "influência +", "cadeia X%"). Descrição, poder × dificuldade e o que acontece na falha ficam em "Detalhes". O Procurado virou um cartão curto: faixa, barra e dois botões (Ficar na sua, Propina), com "Como funciona" recolhido. Treino em grade de 4, Bico numa linha.
- **Noite:** dose com energia e vício em fichas; casas só com o cardápio e a entrada; a explicação do vício em "Como funciona".
- **Feira:** cada item com uma linha (Poder, Defesa ou Fuga e carga).
- **Perfil:** classe com vantagens e custos em lista; influência com a faixa e o que falta em cada bairro.
- **Negócios:** renda por dia, bairro e preço.
- Os textos das faixas de Procurado e de influência ficaram sem números.

### Teto de respeito por degrau, Negócios, seletor da Feira e casas da noite (v1.5)

- **Teto de respeito por degrau:** cada degrau da escada só dá respeito enquanto o seu respeito for menor que **5 × n × (n + 4)**: 1º até 25 (abaixo dos 30 do bando), 2º até 60, 3º até 105, 4º até 160, 5º até 225… Acima disso o roubo continua pagando dinheiro, mas não sobe o placar. Vale junto com a regra de 3 degraus abaixo do maior já feito. Quem fica no roubo fácil não destrava o jogo nem sobe no ranking; o cartão do roubo avisa.
- **Banco e Negócios separados** na Cidade: **Banco** (depósito, saque e patrimônio) e **Negócios** (estabelecimentos e os esquemas de produção, que saíram do Galpão). O Galpão ficou com a mercadoria e o comprador de fora.
- **Feira com seletor** no topo: Arma, Proteção e Veículo, uma prateleira por vez.
- **Casas da noite:** a entrada de cada casa é paga **uma vez por dia**; sair e voltar no mesmo dia é de graça e não repete os acontecimentos da porta (batida, briga, contatos, ânimo). Sem limite de saídas e sem aumento de preço. Dentro da casa a tela vira o ambiente dela (imagem, cardápio e botão **Sair**).
- **Cardápio:** Boteco do Zé: Cigarro, Crakudinha, Pinga com mel. Pagode na laje: Cerveja, Batida de maracujá, Erva. Baile de favela: Whisky falsificado, Loló, Pó. (Inferninho e Termas não mudaram.) Doses novas: Crakudinha (+15 de energia, R$ 19, vício +2) e Batida de maracujá (+28, R$ 45, vício +4).

### Ranking: Mural do respeito (v1.5)

Tela própria de Ranking, sem aba nova. Abre por três caminhos: **tocar na estrela de respeito no topo**, o **cartão da Rua** ("Você é o 12º de 340 · faltam 8 de respeito para passar Fulano · o mês acaba em N dias"; aparece depois dos primeiros passos) e o lugar **Mural do respeito** na Cidade.
- **Top do mês** (50 primeiros): posição, retrato, vulgo, cidade, classe, patente, quantos bairros comanda e respeito. A sua linha fica destacada, e o cartão "Você" mostra sempre a sua posição e quanto falta para passar quem está logo acima.
- **Filtro:** Brasil ou só a sua cidade.
- **Galeria da fama:** os 3 primeiros de cada mês que passou (últimos 6 meses), para sempre.
- **Offline:** sem ranking de jogadores (não se inventa jogador falso); a tela mostra os seus recordes por temporada e o convite para jogar com conta.
- Servidor: migração `0003_ranking.sql` (funções `ranking_mes`, `minha_posicao` e `galeria`, tabela `historico`). A função `jogar` grava o respeito final de cada mês quando o save vira para o mês seguinte; quem não voltou entra na galeria pelo próprio save.

### Regiões e fundo com textura (v1.5, pedido do autor)

- **Bairro virou região.** As cinco áreas de toda cidade agora têm nome fixo, para o jogador se localizar na hora: **Região Central** (centro), **Região Portuária** (cais), **Região Residencial** (jardim), **Região Industrial** (industrial) e **Região da Boêmia** (vila). Regras, números, cores e ids internos não mudaram, então os saves continuam valendo.
- **Sem nome inventado de ponto** (pedido do autor, revisão seguinte): placa, Roubar, ajuda, Cidade e frases da Rua mostram só a região ("Região Portuária · Rio de Janeiro"). As frases de chegada também falam da região ("A Região Central nunca dorme…").
- Todos os textos dizem "região" ("Desta região", "Polícia na região", "Comprar passagem e ir").
- **Fundo com textura pintada por região**, repetida e escurecendo para baixo: paralelepípedo (Central), chapa de contêiner (Portuária), tijolo baiano (Residencial), chapa de aço com faixa zebrada (Industrial) e calçadão em ondas vinho com confete (Boêmia). As imagens ficam em `art/textura-<tipo>.webp` (512 × 512, sem emenda, cerca de 120 KB as cinco). A antiga listra vertical e o brilho colorido no topo saíram; a cor da região continua nas bordas e nos títulos.

### Jornal do Submundo e Diário em agenda (v1.5, pedido do autor)

**O jornal da manhã** fica na Rua, no lugar do "Hoje na cidade". Papel-jornal com cabeçalho (edição da cidade, dia, semana do mês), **manchete com foto** (a pintura da região em preto e branco, com retícula) e notícias em colunas com fio. Cada notícia é um atalho: tocar leva à tela dela.

Visível de cara: a manchete, a **Coluna do respeito** (patente, quanto falta para a próxima e ranking do mês ou temporada), o **quadro do bicho** e as duas notícias mais importantes. O resto fica em "Ler o jornal inteiro".

As notícias saem de `SB.jornal(s)` (motor, só leitura) e o texto de `jornalNews` (`ui.js`). A notícia mais importante vira manchete:

| Seção | Notícia | Peso |
|---|---|---|
| Extra | Patente nova agora há pouco; o que o respeito de hoje abriu (carimbo vermelho EXTRA) | 99 / 94 |
| Carreira · Novidades | Patente nova ontem; o que o respeito de ontem abriu (arma, colete, veículo, casa da noite, mercadoria, esquema, assalto, adversário, lugar) | 98 / 86 |
| Bicho | Resultado da extração de ontem com o seu jogo (pago ou não) | 97 / 66 |
| Polícia | Você rodou ontem; você está caçado ou na mira; a região com mais polícia e a mais calma | 90 / 76 / 40 |
| Gangues | Você tomou ou perdeu uma região; um grupo tomou região de outro; o movimento da noite | 88 / 74 / 34 |
| Porto | O comprador de fora atracou hoje (sem dizer o que quer nem quanto paga); barco previsto em até 2 dias | 80 / 44 |
| Hoje · Continua · Previsão | Evento que começou hoje, evento em andamento, evento fixo de amanhã | 78 / 48 / 46 |
| Ontem | Roubos certos e errados, respeito e patrimônio do dia | 70 ou 52 |
| Galpão | Mercadoria que mais subiu ou caiu desde ontem (10% ou mais; uma por mercadoria); a rota do dia (onde comprar e onde vender) | 50–60 / 42 |
| Negócios | Sua casa que fatura alto hoje por evento; o negócio da vez (o que se paga mais rápido e cabe no bolso) | 58 / 38 |
| Fofoca | O próximo desbloqueio e quanto falta | 30 |

**Foto da manhã:** na virada do dia o motor guarda `paper.cur` (respeito, patrimônio, Procurado, roubos, prisões, líder de cada região e preços do Galpão) e passa a anterior para `paper.prev`. O jornal compara as duas. Saves antigos começam com a foto de agora (sem notícias de "ontem" no primeiro dia).

**Bicho no dia seguinte:** a fezinha vira bilhete (`bicho.tickets`, até 6 por dia) e o dinheiro sai na hora. A extração é feita na virada do dia, com um sorteio para todos os bilhetes daquele dia. Quem acerta recebe 18× (Bicheiro 20×), na mesma conta de antes. O resultado (`bicho.last`) sai no jornal, nas Apostas e no resumo do dia. Sem bilhete, o jornal ainda publica o bicho que deu (sem usar o sorteio do motor). No último dia do mês não há fezinha. A simulação deu os mesmos números de antes, porque os robôs não jogam bicho.

**Diário em agenda:** folha amarelada e gasta, com argolas, margem vermelha, pautas e orelha dobrada, escrita à caneta azul com a fonte **Caveat** (OFL, embutida no arquivo: `fonts/`, cerca de 49 KB, nada é baixado). Cada fato vira uma linha: a virada do dia fica em **Madrugada** e as ações em **Durante o dia**, em ordem de acontecimento (as 6 últimas visíveis e as mais cedo em "N anotações mais cedo"). Uma marca na margem mostra o tom: ✓ ganho, ✗ perda, – neutro. "Folhear os dias anteriores" abre uma página por dia. **O Diário é só o histórico do jogador**: movimentos dos grupos, eventos da cidade e o navio no porto ficam no jornal; fala de grupo só entra quando é com você (retaliação, cobrança, aliança). Roubo que falha sem perda de caixa não escreve mais "Perda de R$ 0".

### Topo, Rua e a redação do jornal (v1.5, pedidos do autor)

**Topo:** a foto ficou 20% maior (53 px). Ao lado vêm o nome, a classe (âmbar) e a patente, cada um numa linha. Procurado e Vício têm o mesmo tamanho de Energia e Saúde. O botão **Dormir** (no online, **Ir pra casa · 3 h** ou **Sair de casa**; no dia 30, **Encerrar**) fica no topo, ao lado do dia, e funciona em qualquer tela. Ele mantém a confirmação ("Dormir com 89?") e fica âmbar quando a energia acaba.

**Rua:** saíram o cartão "E agora?" e a faixa do dia (o dia já está no topo; a semana está no cabeçalho do jornal; no online, "o dia vira em…" também). O texto do momento virou a **legenda da cena**, colado na moldura da região, com o rótulo "A rua agora" e aspas na cor da região.

**Redação** (`src/redacao.js`): o jornal tem equipe própria (inventada), e cada notícia é assinada:

| Jornalista | Cobre |
|---|---|
| Kelly Manchete | editora-chefe: carreira, patente, balanço do dia, feitos |
| Tuca do Plantão | plantão: EXTRA (o que abriu agora há pouco) |
| Zé da Pauta | polícia: prisões, cerco, esfriou, blitz, armas, duelos |
| Lourival Pé-de-Ouvido | gangues: quem tomou o quê, o movimento da noite, bando |
| Tião Cotação | Galpão e porto: altas, baixas, rota do dia, remessas |
| Seu Bené da Banca | o bicho |
| Dona Neide | fofoca: o próximo desbloqueio quando falta pouco |
| Cida Previsão | eventos de hoje e de amanhã |
| Marquinhos Classificado | negócios: casa lotada, compra, negócio da vez, banco |
| Doutora Rosinha | saúde: overdose, vício alto, ferimento |
| Juca Crônica | crônicas da cidade e decisões da história |
| Bia Lente | a foto da manchete |

- **Só publica o que aconteceu.** Cada pauta depende de um fato que o motor registra na foto da manhã: patente, desbloqueios, degrau novo, roubos, prisões, bicho, negócio comprado, arma/colete/veículo novo, duelos, bando, overdose, feitos, vendas e remessas, blitz, depósito, capítulo da história, vício e saúde, eventos, gangues, polícia (só com cerco de 35 ou mais, na mira/caçado, ou quando o Procurado esfria), Galpão (variação de 10% ou mais; rota só com 15% de margem), negócio da vez (só se couber no bolso) e fofoca (só a 15 de respeito ou menos).
- **Muda todo dia:** cada pauta tem várias versões de título e texto, e a do dia é escolhida por uma semente (dia, temporada e vulgo). O mesmo dia mostra sempre a mesma edição.
- **A cidade vive sem você:** em 4 de cada 5 dias sai uma **crônica** (40 histórias da vida da cidade, com região, grupo e boteco da sua cidade). Toda edição traz a **frase ouvida na rua** (40 ditados, com 10 lugares onde foram ouvidos) e, no jornal inteiro, dois **classificados** (24, de brincadeira) e o **expediente**.
- Ao todo são mais de 250 modelos de texto. Um teste de interface monta todos e recusa texto com buraco.

### Evolução no Perfil (v1.5, pedido do autor)

Gráfico de **barras verticais em escada** no Perfil, logo abaixo da ficha. Cada barra é uma pilha de degraus de concreto: os preenchidos são âmbar, o atual brilha e a barra completa ganha borda dourada. Todas as barras têm a mesma altura, então o que se compara é o quanto falta em cada área. Tocar numa barra mostra o detalhe e um atalho para a tela certa. Em "Como cada nível é contado" há a tabela com os mesmos números.

| Barra | Nível | Máximo |
|---|---|---|
| Roubos | o maior degrau já feito com sucesso (`ladderMax`) | 13 |
| Armas | a melhor arma já comprada, na ordem de poder (a de troféu conta como a mais forte) | 15 |
| Proteção | a melhor proteção já comprada | 6 |
| Veículo | o melhor veículo já comprado | 5 |
| Negócios | faturamento da temporada: diárias dos estabelecimentos (inclusive a casa abastecida com a produção) + venda e remessa do que os esquemas produziram + mensalidades do gatonet | 10 |

Os degraus de **Negócios** são R$ 250, 600, 1.200, 2.000, 3.000, 4.500, 6.500, 9.000, 12.500 e 17.000. Foram calibrados com os robôs da simulação: quem vive de negócio fatura de R$ 3.000 a R$ 5.000 no mês (níveis 5 e 6) e chega a R$ 12.000 no topo (nível 9).

Para separar a produção do que foi comprado no Galpão, o motor guarda `made` (o estoque que veio dos esquemas). Numa venda, a parte produzida entra no faturamento. Blitz, batida, dose e abastecimento nunca deixam `made` passar do estoque. `ledger` guarda as duas somas, e as duas zeram na temporada nova.

### Esquina: os jogadores se encontram (v1.5, online, pedido do autor)

Lugar novo no menu Cidade, **só no modo online** (offline, a tela explica e não abre o chat). Três abas:

**Papo.** Duas salas: a da sua cidade e a Geral. As mensagens aparecem como bilhetes colados num muro, se atualizam a cada 6 segundos e ficam visíveis por 3 dias. Embaixo de cada uma: **Desafiar**, **Bloquear** (só no seu aparelho) e **Denunciar** (com 3 denúncias, a mensagem some).
- Regras do chat: até 200 letras e um intervalo de 2,5 s entre mensagens (no máximo 12 por minuto).
- Palavrão passa, porque o jogo é 18+. Não passam ódio e preconceito, ameaça de violência sexual, link nem telefone ou documento.

**Desafios** (combate entre jogadores):
- Você chama alguém pelo vulgo ou pela lista "Na rua agora" (quem jogou nos últimos 20 minutos).
- **Aposta igual dos dois**, de R$ 50 até o teto da patente: Pé de chinelo R$ 300, Rato de pista R$ 1.500, Linha de frente R$ 4.000, Gerente R$ 10.000, Dono do morro R$ 25.000.
- **Chance pela força de luta** (Força, Astúcia, arma, proteção e bando), de 10% a 90%, sorteada no servidor. Quem recebe o desafio vê a própria chance antes de aceitar.
- **Vencedor:** leva o pote menos 10% da banca e ganha +3 de respeito, com teto de 6 por dia vindo de desafios. Bater em quem tem menos da metade do seu respeito não dá respeito.
- **Perdedor:** fica sem a aposta, perde 2 de respeito e leva um golpe de 18 na saúde (a proteção reduz).
- **Limites:** 3 desafios lançados por dia, 1 por rival por dia, no máximo 5 esperando resposta para a mesma pessoa, e saúde de pelo menos 30.
- O desafio vence em 24 horas; recusado, cancelado ou vencido, a aposta volta.

**Mercado negro:**
- Só entra o que os seus esquemas produziram (a mercadoria comprada no Galpão ou de outro jogador não pode ser revendida aqui).
- **Preço livre na faixa** de 50% a 300% do preço base, o que impede passar dinheiro entre contas. A banca mostra quanto a oferta está acima ou abaixo do Galpão de onde você está.
- Até 5 ofertas por vez; recolher devolve a mercadoria.
- Quem compra paga na hora. O vendedor recebe, menos 5%, da próxima vez que entrar, e o valor conta no faturamento de **Negócios** (Evolução no Perfil).

**Como funciona por dentro:** as regras ficam no motor (`SB.pvp`) e o servidor só guarda as ofertas, os desafios e as mensagens. O que cabe ao outro jogador (venda paga, resultado, aposta devolvida) é entregue quando ele entra, com aviso em "Enquanto você esteve fora" e no Diário. Ninguém grava o save de outro jogador, e nada é comprado ou aceito duas vezes.

### Cartão de roubo com foto grande (v1.5, opção B do autor)

- A ilustração do roubo passou de 46 para 96 px, à esquerda, ocupando a altura do nome e das fichas.
- Nome, chance e fichas (saque, energia, Procurado, respeito) ficam ao lado da foto.
- O botão virou **Roubar**, compacto (38 px de altura e só do tamanho do texto), à direita, na mesma linha de "Detalhes". Aberto, o Detalhes desce para a linha de baixo.
- Cabem cerca de 3 cartões por tela, como antes.

### Cartões de chapa e itens trancados (v1.5, pedido do autor)

- **Todos os cartões** (roubos, Feira, Galpão, Negócios, noite, Esquina, lugares da Cidade) são uma chapa de metal escovado, presa por um **parafuso enferrujado em cada canto**, com um fio de ferrugem escorrendo dos parafusos de cima. É feita só em CSS (`--chapa` em `extra.css`) e não pesa no arquivo.
- **Trancado:** o cartão fica **na sombra**: a mesma chapa escurecida, a foto em cinza escuro e o texto apagado, sem transparência (o muro não aparece mais por dentro). Uma **tábua de madeira pregada** atravessa a foto com **TRANCADO** pintado. Nas fotos pequenas a letra é menor, para a palavra caber inteira. O motivo ("Abre com 15 de respeito", "Requer…") continua legível embaixo.

### Feira com foto maior (v1.5, pedido do autor)

A foto do item na Feira passou de 52–64 px para 96 px (como nos roubos). Nos itens trancados, a palavra da tábua cresceu junto.

O cartão também foi reorganizado, com as mesmas informações:
- **EM USO** (dourado) ou **É SEU** (verde) é uma faixa na base da foto, então o nome fica sempre sozinho na primeira linha.
- Poder, defesa, fuga e carga viraram fichas.
- Uma linha só, alinhada com o pé da foto, mostra o preço e Comprar, "na sua mochila" e Usar, ou "equipado agora".
- O cartão fica da altura da foto, sem vão vazio.

### "Enquanto você esteve fora" em folha de Agenda (v1.5, online, pedido do autor)

Ao voltar ao jogo online, o resumo abre como uma folha da Agenda: argolas, letra de caneta, o **Dia** e, ao lado, quanto mudou desde a última vez que você viu o jogo ("+R$ 340 · +3 respeito · −10 saúde", guardado no aparelho).
- **Com você:** no máximo 5 linhas, as mais importantes primeiro: cadeia, UTI, desafio, venda, bicho, batida e respeito. O resto fica em "E mais N anotações no Diário".
- **Na cidade:** só os eventos.
- **Gangues:** uma linha só ("E mais: 3 movimentos das gangues na Região Portuária e na Região Industrial. Tudo no Jornal da Rua.").
- **Botão:** "Bora pra rua →".
- **Só abre quando há algo com você.** Se foi só a cidade se mexendo, o jornal da Rua já conta.

### Noite organizada (v1.5, pedido do autor)

As casas da noite seguem o padrão da Feira:
- **Foto:** em retrato, com 96 px de largura e a altura toda do cartão, como o cartaz da porta da casa.
- **Selo** na base da foto: "Entrada paga", "Você está aqui" ou "Sua casa".
- **Texto:** a descrição vai em itálico e as bebidas da casa viram fichas.
- **Linha de baixo:** "Entrada R$ 40" e Entrar; se já pagou, "pode entrar e sair hoje" e Voltar.
- **Trancadas:** o motivo fica embaixo do nome, com a tábua na foto.

### Pop-ups com cara (v1.5, pedido do autor)

- **Escolha da história** → página do capítulo: quem fala, "Capítulo N de 5", o título, "Você escolheu: …", a consequência em itálico com margem vermelha, o efeito em ficha e o botão "Seguir em frente".
- **Roubo, duelo e assalto do bando** → boletim:
  - foto com o carimbo DEU BOM (verde) ou DEU RUIM (vermelho);
  - o que aconteceu e as fichas de ganho e perda;
  - os botões Voltar e **Roubar de novo** (só aparece quando o mesmo roubo ainda pode ser feito).
- **Dose na noite** → comanda do bar: a dose e o preço, a energia, o vício (até 100), o total e um recado à caneta do dono, com os botões "Fechar a conta" e **Pedir outra**.
- **O resto** (propina, banco, treino, viagem…) → bilhete limpo com letra legível (sai a máquina de escrever espaçada), faixa âmbar à esquerda (vermelha quando deu errado) e fichas de ganho e perda.

### Recibo de compra (v1.5, pedido do autor)

Toda compra abre um **recibo** no lugar do cupom de texto: Feira do Rolo, negócio ("Contrato de compra"), esquema montado ou ampliado ("Esquema montado" / "Obra de ampliação"), mercadoria do Galpão ("Nota de carga") e mercado negro da Esquina.

O recibo traz:
- a foto do que você comprou, com o carimbo verde **PAGO**;
- o que muda para você: "Poder 4 (+1)" comparado com o que você usava, a renda por dia do negócio, a produção do esquema ou a carga do galpão;
- a conta: o valor pago e o que sobrou no bolso;
- dois botões: **continuar ali** ou ir para a tela certa ("Ir roubar" depois de uma arma; "Voltar pra Rua" depois de negócio, esquema ou carga; "Ver o Galpão" depois do mercado negro).

### Sons (v1.5)

Efeitos sintetizados pelo navegador (Web Audio, `src/sound.js`), sem arquivos de áudio e sem licença: roubo certo = caixa registradora + carimbo; roubo errado = som grave + carimbo; preso = sirene; compra, venda, banco, propina, fiança e aposta = moedas; dose = lata abrindo; entrar na noite = batida grave; treino = soco; hospital e desintoxicação = bipe de monitor; UTI = monitor apitando direto; respeito novo (faixa de influência, feito do mês, primeiros passos, conquista) = fanfarra curta; virar o dia = sino; ação recusada = bipe curto. Botão de alto-falante no topo (ao lado do dia) e volume no Perfil; a escolha fica no aparelho. O áudio só começa depois do primeiro toque (regra dos celulares).

### Dono da Noite: respeito na noite (v1.5)

O +1 de respeito do Dono da Noite agora vale só na **1ª saída da noite de cada dia** (antes, a cada saída, até 3 por dia). Motivo: com a noite virando parte do ciclo de todo mundo, o Dono da Noite chegava a 262 de respeito, à frente de todas as estratégias.

### Tela de escolha da classe (v1.5)

Cada classe aparece com imagem, uma frase de resumo, vantagens (✓) e custos (✗); ao tocar, aparece "✓ Escolhida" e as habilidades por nível. Textos conferidos com as regras: o Bicheiro perdeu o "−5 nos roubos de Força" (não existe na escada) e ganhou "negócios custam 12% menos"; o Assaltante mostra o +25% de respeito nos assaltos; o Dono da Noite, o +1 de respeito a cada saída na noite.

### Influência no ciclo do roubo (v1.5, desenhado com o autor)

**Respeito diz quem você é na cidade; influência diz onde você manda.** A influência é uma barra por bairro (0–100) e nunca entra no placar.

**Roubar dá influência.** Todo roubo bem-sucedido do 4º degrau em diante soma influência no bairro onde foi feito: golpe +2, genérico e assalto +1, multiplicado por (1 − influência ÷ 100), cada vez menos conforme a barra enche (Articulador ×1,3). Os degraus 1 a 3 não somam. Continua subindo também com Criar contatos (R$ 180 · 22 de energia), o Favor de vizinhança (+4), as notícias e o pagode; cai 1 por dia nos bairros onde você não está, e os grupos rivais tomam.

**Faixas com nome:**

| Faixa | Nome | O que libera |
|---|---|---|
| 0–19 | Desconhecido | nada |
| 20–39 | Conhecido | disputar o bairro e confrontar facções |
| 40–59 | Respeitado | Leilão clandestino (antes 25) e criar contatos 20% mais barato |
| 60 e 10 acima do grupo que manda | **Dono do pedaço** | +12% nos roubos daqui, +15% nos negócios daqui, **propina 25% mais barata**, **a polícia do bairro sobe pela metade** nos seus roubos e a vantagem do bairro |

**Respeito × influência** (desenho com o autor):
- **A patente limita quantos bairros você segura:** Pé de chinelo 0, Rato de pista (30) 1, Linha de frente (90) 2, Gerente do movimento (150) 3, Dono do morro (230) todos os 5. Se você tem influência para mandar em mais bairros do que a patente permite, ficam os de maior influência; os outros aparecem como "pronto para mandar, mas falta patente".
- **Subir de faixa num bairro paga respeito**, uma vez por bairro na temporada: Conhecido +3, Respeitado +5, Dono do pedaço +10. Substitui o antigo feito de Território (que saiu dos feitos do mês; save antigo entra com as faixas que já tinha dadas como pagas).
- **Perder o comando de um bairro custa 5 de respeito**, quando a influência cai (rival, ausência). Perder por falta de patente (respeito que caiu) não cobra. Retomar não paga de novo.

**Onde aparece:** na faixa da placa (Rua e Bairros), "Sua influência 46 · Respeitado"; o "?" explica as faixas, quanto falta para ser o dono, e mostra Dono, Grana e Polícia. Na tela Roubar, uma linha logo abaixo do Procurado ("Influência em X: 46 · Respeitado" ou "Você manda em X: +12% no saque…"). No Perfil, uma linha por bairro com a faixa e o que falta.

### O ciclo do roubo (v1.5, desenhado com o autor)

**Ciclo:** Roubar → recuperar energia → roubar → tirar o Procurado → comprar arma, proteção e transporte → roubar → tirar o vício → recuperar energia → roubar… Cada etapa consome o que a anterior produziu (dinheiro, energia, Procurado, vício), e nenhuma tem número fixo que trave o iniciante. As etapas vão aparecendo sozinhas: no começo é só roubar e beber; a ficha, a Feira e a clínica entram conforme o jogador sobe.

**A escada.** 13 roubos de rua, do mais fácil ao mais difícil, mais 5 variações que só existem num bairro (mesmo degrau, saque +15%). Não há trava por respeito: a própria chance mostra se você está pronto. Ficam só as travas temáticas (os assaltos grandes pedem arma e veículo, o Caminhão pede bando, o Leilão pede influência no bairro, o Cofre é uma vez por dia).

| # | Roubo | Tipo | Dificuldade | Energia | Saque | Procurado | Respeito | Cadeia ao falhar |
|---|---|---|---|---|---|---|---|---|
| 1 | Bater carteira | Genérico | 11 | 13 | R$ 32–47 | +2 | 1 | não |
| 2 | Fiação de cobre | Genérico | 16 | 16 | R$ 55–80 | +3 | 1 | não |
| 2 | Favor de vizinhança (só jardim) | Golpe · Influência | 14 | 16 | R$ 60–90 | +2 | 1 | não |
| 3 | Barraquinha de pastel | Genérico | 19 | 19 | R$ 85–125 | +5 | 1 | não |
| 4 | Celular no ponto de ônibus | Genérico | 22 | 22 | R$ 130–195 | +6 | 2 | 18% |
| 5 | Rolo na feira | Golpe · Lábia | 24 | 25 | R$ 200–305 | +5 | 2 | 14% |
| 5 | Esquema do camelódromo (só centro) | Golpe · Astúcia | 24 | 25 | R$ 230–350 | +5 | 2 | 14% |
| 6 | Cobrança atrasada | Assalto | 24 | 28 | R$ 305–460 | +12 | 2 | 28% |
| 7 | Clonar cartão de velho rico | Golpe · Astúcia | 31 | 31 | R$ 405–610 | +7 | 3 | 16% |
| 7 | Bastidores do baile (só vila) | Golpe · Lábia | 31 | 31 | R$ 465–700 | +7 | 3 | 16% |
| 8 | Mercadinho Dois Irmãos | Assalto | 31 | 34 | R$ 535–800 | +15 | 3 | 32% |
| 8 | Carga sem dono (só cais) | Assalto | 31 | 34 | R$ 615–920 | +15 | 3 | 32% |
| 9 | Leilão clandestino | Golpe · Lábia | 37 | 37 | R$ 695–1045 | +9 | 4 | 19% |
| 10 | Caixa eletrônico na maquita | Genérico | 46 | 40 | R$ 905–1355 | +15 | 4 | 28% |
| 11 | Casa lotérica | Assalto | 40 | 43 | R$ 1165–1750 | +21 | 4 | 38% |
| 11 | Galpão desativado (só industrial) | Assalto | 40 | 43 | R$ 1340–2015 | +21 | 4 | 38% |
| 12 | Caminhão de carga na rodovia | Assalto | 45 | 46 | R$ 1500–2245 | +23 | 5 | 40% |
| 13 | Cofre da joalheria | Golpe · Astúcia | 50 | 49 | R$ 1915–2870 | +13 | 5 | 24% |

**O degrau 1 é do autor:** R$ 32–47, 13 de energia, +2 de Procurado e cerca de 90% de chance para o personagem novo. A 1ª arma (R$ 150) sai em uns 4 roubos.

**A chance vem da conta**, nunca de um número fixo:
- **Poder no roubo** por tipo: **genérico** = soma dos atributos + 3 por ponto de arsenal; **golpe** = 3 por ponto do atributo principal + 1 por ponto de arsenal; **assalto** = metade da soma dos atributos + 3 por ponto de arsenal + 1,5 por nível do bando. Arsenal = poder da arma + defesa da proteção + fuga do veículo.
- **O Procurado tira poder em porcentagem**: Procurado + metade da polícia do bairro, ÷ 250 (com 50, −20%). Saúde abaixo de 60 também tira (0,4% por ponto). Dica de informante: +15%.
- **Chance = curva da proporção poder ÷ dificuldade**: empate = 70%, 1,5 vez = 90%, teto 95%, piso 5%. A dificuldade sobe com o risco do bairro e dos eventos.
- **Dificuldade de cada degrau** = poder do jogador típico no dia em que ele chega ali × 0,75 (degraus 2 a 4) ou 0,85 (5 em diante) × 0,88 (Procurado típico de 30). Jogador típico, medido no robô do ciclo: soma dos atributos 17 + 0,3 por dia, melhor atributo 6 + 0,4 por dia, arsenal 2 + 0,55 por dia.
- **Saque por energia**: R$ 3 no degrau 1, +35% por degrau até o 6, depois +20%, até cerca de R$ 49 no 13.

**Falhar:** nos degraus 1 a 3, só perde a energia (sem cadeia e sem perder caixa). Do 4 em diante: perde parte do caixa em mãos, pode ser preso, e os assaltos ferem.

**Repetir é livre.** O freio é o Procurado. **Respeito**: cerca de 0,4 por degrau (mínimo 1, máximo 5); roubo 3 ou mais degraus abaixo do maior que você já fez dá dinheiro, mas não dá respeito. Assaltante: +25% de respeito nos assaltos.

**Gatilhos do Procurado:** 0–29 Na moita · 30–59 De olho · 60–84 Na mira (+10 de cadeia ao falhar, do degrau 4 em diante) · 85+ Caçado (do degrau 4 em diante, até o roubo que deu certo pode virar enquadro: perde o saque e 1 dia preso).

**Propina** (substitui o despachante): −25 de Procurado. A polícia cobra pela sua ficha: a 1ª do dia custa o saque médio de 1 roubo do **maior degrau que você já fez**; cada nova no mesmo dia, +50%. Sem teto. Também esfriam: ficar na sua (18 de energia, −20), trocar de bairro, bico, dormir e o tempo.

**Energia e doses.** Sem limite de doses e sem teto por dia. As doses levam a energia **até 200** (a recuperação natural para em 100).

| Dose | Energia | Preço | R$ por energia | Vício |
|---|---|---|---|---|
| Cigarro | 3 | R$ 3 | 1,0 | 0 |
| Cerveja | 10 | R$ 12 | 1,2 | 1 |
| Crakudinha | 15 | R$ 19 | 1,3 | 2 |
| Pinga com mel | 20 | R$ 28 | 1,4 | 3 |
| Batida de maracujá | 28 | R$ 45 | 1,6 | 4 |
| Whisky | 35 | R$ 70 | 2,0 | 5 |
| Erva | 50 | R$ 110 | 2,2 | 6 |
| Loló | 70 | R$ 200 | 2,9 | 12 |
| Bala | 100 | R$ 350 | 3,5 | 20 |
| Pó | 150 | R$ 700 | 4,7 | 32 |

A fraca é barata por ponto (o iniciante lucra); a forte é cara, mas dá muito de uma vez. Freios: tolerância (a mesma dose rende 15% menos a cada vez no dia), vício (com 100 a dose dá metade), overdose nas fortes acima de 70 de vício, e o bolso.

**Tirar o vício custa saúde:** 0,5 de saúde por ponto de vício removido (soro: −20 de vício e −10 de saúde; clínica: zera o vício, R$ 18 e 0,5 de saúde por ponto). **Saúde zero = UTI**: 24 horas sem jogar no online; no jogo local, o resto do dia e o seguinte. Na UTI a saúde não sobe; você sai com 40 de saúde e o vício zerado. A **clínica particular** (saúde cheia por R$ 12 o ponto) fica 50% mais cara a cada uso no mesmo dia.

**Feira** ajustada à escada: preço = antigo × (0,35 + antigo ÷ 12.000), no máximo 1 (Pedaço de pau R$ 150, Chave de fenda R$ 340, Vergalhão R$ 460, Facão R$ 680, Maquita R$ 970, Três-oitão R$ 1.030, Pistola R$ 1.590…; a partir de uns R$ 7.700, igual a antes). Proteções: Lista R$ 70, Jaqueta R$ 380, Colete R$ 1.250… Veículos: Bicicleta R$ 110, Cinquentinha R$ 800, Moto R$ 1.890…

### Resultado em popup e sem meta (v1.5)

- O resultado de **toda ação** (roubo, compra, negócio, noite, dormir…) não fica mais no topo da tela: ele **pula num popup** no centro, no estilo cupom com carimbo, com o que mudou (caixa, energia, Procurado, respeito) e as linhas do resultado. Fecha no **OK**, no × ou tocando fora (Esc no computador). A animação respeita `prefers-reduced-motion`.
- A **meta da temporada saiu**: não há mais escolha até o dia 5, nem +20 de respeito, nem R$ 600 de legado, nem a conquista Determinação. O guia tem 8 passos (quem estava no meio dele, depois da meta, volta uma posição). Na ficha, o bloco "Meta" virou **Mês** (dia e quanto falta).

### Luta, força do bando e poder da arma (v1.5)

Três nomes, três medidas: **poder** é só da arma (abre roubos e soma nas chances); **Luta** é a sua, mostrada no Perfil com a conta aberta: Força × 1,6 + Astúcia × 0,6 + poder da arma × 1,8 + defesa da proteção + nível da sede × 1,5 (Assaltante: arma e proteção +15%); vale nos duelos (+2,2% de chance por ponto acima do adversário) e é a base da **Força do bando** nos assaltos (mais nível e número de integrantes, Músculos e avulsos). Também pesam: saúde abaixo de 60, cansaço do dia, Procurado, ânimo e informação. O antigo "Poder na cidade" virou **Domínio da cidade** (influência nos bairros, não luta).

### Entrada e ficha da temporada (v1.5)

Sequência: **tela inicial** (aviso 18+, entrar ou criar conta, ou jogar sem conta) → **ficha 1**: retrato (10), vulgo e cidade, botão **Próximo** → **ficha 2**: classe (4), e só depois de escolher aparecem o aviso "retrato, vulgo e classe só poderão ser alterados na próxima temporada" e o botão **Salvar** → o **guia de primeiros passos** começa direto no passo 2 (primeiro roubo). A ação é `setup(retrato, vulgo, classe)`, que só vale sem classe; ao virar a temporada a ficha reabre com o vulgo preenchido (a cidade não muda). O Perfil não troca mais o retrato. No online, o vulgo novo precisa ser único (o banco recusa repetido).

### Itens são seus (v1.5)

Na Feira, comprar paga o **preço cheio** e o item fica **seu** na temporada; os que você já tem mostram **Usar** (troca de graça, recusada preso ou com veículo menor que a carga). Não há mais devolução de metade na troca, então os preços caíram pela regra *novo = antigo − metade do anterior da mesma prateleira*: o custo para subir a trilha ficou igual (o ritmo medido em `npm run ritmo` não mudou). Patrimônio conta só o que está em uso (itens guardados não viram dinheiro).

| Arma | Preço | | Proteção | Preço | | Veículo | Preço |
|---|---|---|---|---|---|---|---|
| Pedaço de pau | 150 | | Lista telefônica | 200 | | Bicicleta | 300 |
| Chave de fenda | 820 | | Jaqueta | 900 | | Cinquentinha | 1.650 |
| Vergalhão | 1.050 | | Colete vencido | 2.300 | | Moto | 3.100 |
| Facão | 1.450 | | Kevlar | 3.100 | | Opala | 5.500 |
| Maquita | 1.900 | | Tático | 4.750 | | Blindado | 11.250 |
| Três-oitão | 2.000 | | Traje | 8.500 | | | |
| Pistola .40 | 2.750 | | | | | | |
| Doze | 3.750 | | | | | | |
| Uzi | 4.500 | | | | | | |
| Submetralhadora | 5.250 | | | | | | |
| FAL | 6.000 | | | | | | |
| AR-15 | 7.750 | | | | | | |
| Ponto Cinquenta | 11.500 | | | | | | |
| MAG | 15.000 | | | | | | |
| Lança-rojão | 18.000 | | | | | | |

### Relógio do modo online (v1.5, fase 1b)

Só no online. O jogo local continua com o botão Dormir e 30 dias por temporada.

| Regra | Online |
|---|---|
| Dia | Vira sozinho à **meia-noite de Brasília**; o dia do jogo é o dia do mês (o dia 31 conta como 30). Na virada entram renda, produção, eventos e facções, e os limites do dia zeram. Quem ficou fora recebe as viradas atrasadas (até 33). |
| Energia | **+1 a cada 3 minutos** (cheia em 5 horas), até 100. A virada não dá mais +70. |
| Ir pra casa | 3 horas sem roubar, noite ou viagem (banco, compras e decisões do bando continuam). No fim: energia cheia, tolerância e teto do corpo zerados. **Até 2 vezes por dia.** Sair antes não dá o descanso. |
| Procurado | Cai aos poucos, no ritmo de 15 por dia × 4 = **60 por dia** (v1.5: a energia volta o dia todo, então o Procurado esfria 4× mais rápido que no jogo local). |
| Vício | −1 a cada 8 horas. |
| Cadeia e hospital | 1 dia do jogo = **2 horas** reais. Fiança, suborno e clínica continuam valendo na hora. |
| Temporada | É o **mês do calendário**: fecha sozinha na virada do mês, com legado, e o ranking recomeça. |

O tempo é contado pelo servidor; o aparelho só prevê energia, Procurado e os contadores entre um pedido e outro. "Dormir" e "Encerrar temporada" são recusados no online.

### Economia do começo (v1.5)

- **Começa sem dinheiro** (R$ 0). A partir da 2ª temporada, entra só o legado (até R$ 2.600 + medalhas). O **Bico** (28 de energia, R$ 110–170, sem risco) é a rede de segurança.
- **Primeiros passos**: enquanto o guia está ativo, roubo que falha antes do primeiro sucesso não dá cadeia.
- **Preços da Feira** recalibrados (antes, 3 roubos compravam a 4ª arma). Regra: a primeira arma sai com 1 roubo; cada arma seguinte custa vários roubos do nível em que você está.

| Arma | Antes | Agora | Poder |
|---|---|---|---|
| Pedaço de pau | 120 | 150 | 1 |
| Chave de fenda | 300 | 900 | 2 |
| Vergalhão | 500 | 1.500 | 3 |
| Facão | 750 | 2.200 | 4 |
| Maquita | 1.200 | 3.000 | 5 |
| Três-oitão | 1.700 | 3.500 | 7 |
| Pistola .40 | 3.300 | 4.500 | 9 |
| Doze | 4.800 | 6.000 | 11 |
| Uzi | 6.500 | 7.500 | 13 |
| Submetralhadora | 8.000 | 9.000 | 14 |
| FAL | 9.200 | 10.500 | 16 |
| AR-15 | 12.000 | 13.000 | 18 |
| Ponto Cinquenta, MAG, Lança-rojão | 18.000 / 24.000 / 30.000 | iguais | 21–26 |

Proteções: Lista 200, Jaqueta 1.000, Colete vencido 2.800, Kevlar 4.500, Tático 7.000, Traje 12.000. Veículos: Bicicleta 300, Cinquentinha 1.800, Moto 4.000, Opala 7.500, Blindado 15.000.

- **Roubo armado paga +25%** (antes +15%), para a arma se pagar.
- **Medalhas e meta acompanham a economia**: Fortuna 6.500 / 10.000 / 14.500 (antes 11 / 17 / 24 mil), Fama 95 / 135 / 185 de respeito (antes 110 / 160 / 220), Comércio 3.500 / 8.000 / 14.000 (antes 4 / 9 / 16 mil); meta Patrimônio R$ 10.000 (antes 18.000).

### Trilha de compra (v1.5)

Na **Feira do Rolo** e nos **negócios**, o próximo item só abre depois que o anterior foi comprado **nesta temporada** (a trilha recomeça a cada mês). Os requisitos antigos (respeito, troféu) continuam valendo; a trilha vem antes deles no motivo do bloqueio. Roubos, noite, duelos, esquemas e assaltos do bando **não têm trilha** (o autor decidiu tirar).

| Trilha | Ordem |
|---|---|
| Armas | Pedaço de pau → Chave de fenda → Vergalhão → … → Lança-rojão (o Fuzil dourado é troféu, fora da trilha) |
| Proteções | Lista telefônica → Jaqueta → Colete vencido → … → Traje tático |
| Veículos | Bicicleta → Cinquentinha → Moto → Opala → Blindado |
| Casas da noite | Pensão → Bar → Inferninho → Casa de Shows → Termas |
| Negócios de rua | Oficina → Banca do bicho → Mercadinho → Depósito |

Save anterior à v1.5 entra com a trilha toda liberada até a próxima temporada.

### Quatro classes (v1.4)

Uma classe por pilar. As tabelas de classe mais antigas deste documento ficam como histórico; esta é a regra atual. A classe Articulador saiu: save que estava nela volta a escolher a classe (o histórico guarda o nome antigo).

| Classe | Vantagens | Desvantagem |
|---|---|---|
| **Assaltante** · Linha de Frente | +20% de dinheiro em todo roubo e assalto do bando; roubos gastam 10% menos energia; arma e colete contam 15% a mais (poder, defesa e dano) | Negócios e esquemas rendem 10% menos |
| **Dono da Noite** · Rei do Inferninho | Casas da noite +30% (+50% com Casa cheia) e 20% mais baratas; entrada e doses 40% mais baratas; whisky, loló, bala e pó sobem metade do vício; +1 de respeito por saída | Nos roubos, a arma conta 20% menos na chance |
| **Traficante** · Dono da Produção | Esquemas produzem +25% e custam 10% menos; Navio paga +10% | Comércio de mercadoria gera 60% mais Procurado; cada esquema de mercadoria ativo soma +1 de Procurado por dia |
| **Bicheiro** · Dono da Área | Gatonet e negócios de rua +35% (casas da noite não); taxa do banco 1,5% (0,75% com Contador); advogado e suborno 30% mais baratos; +1 de respeito por dia a cada R$ 10.000 no banco (até +3); bicho paga 20× | Roubos de Força com −5 de chance; treino de Força 25% mais caro |

As três habilidades por classe (níveis com 10, 25 e 45 de XP) continuam as mesmas de antes. Os números de 20%, 25% e 35% são os propostos pelo autor; o Navio do Traficante (proposto +15%) ficou em +10%, e a casa abastecida (proposta em dobro) ficou em +70%, porque a produção passava dos outros caminhos na simulação.

### Noite com cardápio (v1.4)

A casa cobra a **entrada** (conta como uma das 3 saídas do dia e traz os riscos da casa: batida, briga, contatos, ânimo); a energia vem das **doses** pedidas no balcão. Limite de 15 doses por dia. A energia de cada dose cai com o vício: `energia × máx(0,4; 1 − vício/160)`.

| Dose | Energia | Vício | Ressaca | Preço | Observação |
|---|---|---|---|---|---|
| Cigarro | +2 | 0 | 0 | R$ 8 | até 5 por dia |
| Cerveja | +5 | +1 | 0 | R$ 15 | |
| Pinga | +10 | +2 | −1 | R$ 30 | |
| Whisky falsificado | +20 | +4 | −1 | R$ 70 | 12% de azia (−5 de saúde) |
| Erva | +30 | +4 | 0 | R$ 100 | melhor energia por vício |
| Loló | +50 | +10 | −2 | R$ 180 | overdose com vício ≥ 70 |
| Bala | +75 | +18 | −3 | R$ 300 | overdose com vício ≥ 70 |
| Pó | +100 | +30 | −3 | R$ 600 | overdose com vício ≥ 70; só nas Termas |

| Casa | Entrada | Abre com | Cardápio |
|---|---|---|---|
| Boteco do Zé | R$ 10 | — | cigarro, cerveja, pinga |
| Pagode na laje | R$ 40 | — | + erva |
| Baile de favela | R$ 60 | — | cigarro, cerveja, whisky, erva, loló |
| Inferninho da Luz Vermelha | R$ 150 | 40 de respeito | cigarro, whisky, loló, bala |
| Termas VIP | R$ 400 | 60 de respeito | whisky, bala, pó |

**O corpo se acostuma**: cada dose do mesmo tipo no dia rende 15% menos (×0,85 por dose repetida; outro tipo rende cheio) e, somando tudo, as doses devolvem no máximo **150 de energia por dia**. Dormir zera os dois. Isso impede o ciclo eterno rouba → droga → clínica → droga: com dinheiro infinito, o máximo cai de cerca de 85 roubos por dia para cerca de 14. No online, o descanso por tempo real ("Ir pra casa") fará o papel do Dormir.

Cada saída a mais no dia encarece a entrada em 50%. Barão: entrada e doses 40% mais baratas, metade do vício. Dono do Bar entra de graça e paga metade no Boteco; dono do Inferninho entra de graça no Inferninho; dono da Termas tem uma recarga cheia, grátis e sem vício por dia. Mercadoria do Galpão serve como dose (cigarro, whisky, erva, loló, bala e pó do estoque).

### Esquemas de produção (v1.4)

| # | Esquema | Custo | Abre com | Rende por dia (nível 1) | Custo/dia por nível |
|---|---|---|---|---|---|
| 1 | Fábrica de gelo saborizado | R$ 500 | 0 | 10 × gelo | R$ 30, sem batida |
| 2 | Galpão de cigarro do Paraguai | R$ 1.200 | 8 | 9 × cigarro | R$ 30 |
| 3 | Depósito de bebida falsa | R$ 2.000 | 15 | 7 × whisky falsificado | R$ 30 |
| 4 | Central de internet (gatonet) | R$ 3.200 | 25 | R$ 200 direto no banco | R$ 30, sem batida |
| 5 | Plantação de maconha | R$ 3.600 | 35 | 6 × erva | R$ 30 |
| 6 | Laboratório químico | R$ 7.000 | 80 | 4 × bala e 3 × loló | R$ 90 (com propina: batida pela metade) |
| 7 | Refinaria do pó | R$ 25.000 | 150 | 3 × pó | R$ 180 (com propina: batida pela metade) |

Níveis 2 e 3 rendem ×1,8 e ×2,6. **Sinergia**: dono do Inferninho com Depósito de bebida falsa ou Laboratório e 5 unidades (whisky, loló ou bala) em estoque abastece a casa e ganha +70% da renda base dela no dia (sem somar bônus de classe); dono da Termas com Refinaria faz o mesmo com 2 de pó. **Pó no Navio** dá o triplo de respeito por remessa. No jogo offline a produção roda ao dormir; no online, rodará por hora.

## 20. Sistemas paralelos (v1.3)

O ciclo de roubos é a espinha dorsal; estes sistemas rodam em volta dele. Não há PvP: a disputa é contra a polícia, o vício, a falência e o relógio do mês.

### Classes (cinco)
| Classe | Vantagem | Desvantagem | Habilidades (10 / 25 / 45 XP) |
|---|---|---|---|
| **Assaltante** | +6 de chance, +8% nos roubos grandes, falhas custam 30% menos | vigilância +10%, negócios −10% | Rota de fuga · Ritmo de rua · Sangue frio |
| **Traficante** | produção −10% de custo e +10% de volume; comprador de fora paga +5% | chance nos roubos −3; negócio de mercadoria chama 60% mais atenção | blitz −12 · carga +15 · batidas pela metade e remessas de 70 |
| **Barão da Noite** | casas da noite +50% e −12% de custo; noitada −40%; +1 de respeito por saída; vício pela metade | recompensa dos roubos −5% | ressaca pela metade · sem batida nem briga na noite · casas +20% |
| **Bicheiro** | negócios +25% e −12% de custo; o bicho paga 20× | chance nos roubos −3 | taxa do banco 1% · crises pela metade · banco rende |
| **Articulador** | influência +30%, diálogos +8, disputas +5 | recompensa dos roubos −10% | contatos −30% · tréguas longas · tributo +60% |

O "Cafetão" do gênero virou **Barão da Noite**: ele lucra com as casas, sem mecânica de contratar ou explorar pessoas. Assaltante e Bicheiro são os antigos Operador e Empreendedor (mesmo código interno; saves continuam válidos). O Articulador foi mantido porque bairros e acordos existem neste jogo.

### Império da noite e do jogo (negócios novos)
| Negócio | Custo | Renda base/dia | Observação |
|---|---|---|---|
| Pensão de beira de estrada | R$ 900 | 48 | casa da noite; o primeiro tijolo |
| Banca do bicho | R$ 3.000 | 165 | |
| Inferninho da Luz Vermelha | R$ 4.200 | 230 | casa da noite |
| Termas VIP | R$ 15.000 | 620 | casa da noite; dá **uma recarga cheia por dia, grátis, sem vício e sem batida** |

Bar e Casa de Shows também contam como casas da noite (bônus do Barão e da Noite de fluxo).

### Vício, overdose e desintoxicação
- Cada saída sobe o vício (Boteco +4, Pagode +5, Baile +9, Termas +3). Cai 3 por dia.
- Recarga da noite × `max(40%, 1 − vício/160)`.
- Com vício ≥ 70, cada saída tem `vício − 60`% de chance (até 40%) de **overdose**: um dia na UPA, −25 de saúde e −3% de respeito.
- Hospital: **Soro na veia** (25 de energia, −20, uma vez por dia) ou **Clínica de desintoxicação** (R$ 18 por ponto, zera).
- **Batida policial** nos lugares baratos (Boteco 8%, Pagode 4%, Baile 10%; ×1,6 na Noite de fluxo): 5% do caixa em mãos (até R$ 500) e +8 de vigilância.

### Apostas (Cidade → Apostas, abre com 8 de respeito)
| Jogo | Chance | Paga | Teto |
|---|---|---|---|
| Jogo do bicho (resultado no dia seguinte) | 1 em 25 | 18× (Bicheiro: 20×) | R$ 20.000 |
| Sinuca valendo dinheiro | 34–49% (Astúcia e Lábia) | 2× | R$ 2.000 |
| Roleta clandestina | 47% | 2× | R$ 20.000 |

Até 6 apostas por dia. A banca tem vantagem em todos os jogos (testado com 10 mil apostas de cada).

### O jogador contra o sistema
- **Colete**: roubo armado que falha vira trocação com a segurança: dano de `8–14 + poder exigido`, reduzido em 80% da defesa. Sem colete, é UPA.
- **Prisão custa respeito**: −4% ao ser preso.
- **Despachante** (tela Roubar): `R$ 150 + 14 × vigilância`, −35 de vigilância, uma vez por dia.

### O mês
| Semana | Dias | Tema |
|---|---|---|
| 1 | 1–7 | A corrida da sarjeta |
| 2 | 8–15 | A construção do império |
| 3 | 16–23 | O bonde pesado |
| 4 | 24–30 | Tudo ou nada |

- **Dia de pagamento** (5 e 20): Mercadinho, Caixa eletrônico, Lotérica, Cofre da joalheria e assaltos do bando +30%.
- **Noite de fluxo** (6, 7, 13, 14, 21, 27): casas da noite rendem o dobro; batida ×1,6.
- **Operação Fecha-Mês** (28 a 30): risco +8 e vigilância gerada +15%.
- **Último Navio** (dia 30): o comprador de fora paga +25%.

### Patentes (por respeito)
Pé de chinelo (0) · Rato de pista (30) · Linha de frente (90) · Gerente do movimento (150) · Dono do morro (230).

### Depende de servidor (não existe nesta versão)
Rodada no calendário real, ranking entre jogadores e de bondes, galeria da fama, renda enquanto offline e a fórmula única de Respeito como pontuação pública. A pontuação da temporada continua nas seis categorias (§9 e §14).
